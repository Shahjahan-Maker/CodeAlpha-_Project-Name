<?php
session_start();
require "config/database.php";

$error="";
$step=1;
$user=null;

if(isset($_POST["find_user"])){

$username=trim($_POST["username"]);

$stmt=$conn->prepare("SELECT id,username,favorite_teacher,first_school,favorite_book FROM users WHERE username=?");
$stmt->bind_param("s",$username);
$stmt->execute();

$result=$stmt->get_result();

if($result->num_rows==1){

$user=$result->fetch_assoc();

$step=2;

}else{

$error="Username not found.";

}

}

if(isset($_POST["reset_password"])){

$username=$_POST["username"];
$teacher=$_POST["teacher"];
$school=$_POST["school"];
$book=$_POST["book"];
$new=$_POST["new_password"];
$confirm=$_POST["confirm_password"];

$stmt=$conn->prepare("SELECT * FROM users WHERE username=?");
$stmt->bind_param("s",$username);
$stmt->execute();

$user=$stmt->get_result()->fetch_assoc();

$step=2;

if(
password_verify($teacher,$user["favorite_teacher"]) &&
password_verify($school,$user["first_school"]) &&
password_verify($book,$user["favorite_book"])
){

if(strlen($new)<8){$error="Password must be at least 8 characters.";}elseif($new==$confirm){

$hash=password_hash($new,PASSWORD_DEFAULT);

$update=$conn->prepare("UPDATE users SET password=? WHERE id=?");
$update->bind_param("si",$hash,$user["id"]);
$update->execute();

header("Location: login.php?reset=success");
exit();

}else{

$error="Passwords do not match.";

}

}else{

$error="Security answers are incorrect.";

}

}

include "includes/header.php";
?>

<div class="container d-flex justify-content-center align-items-center" style="min-height:100vh;">

<div class="card-glass p-5" style="max-width:650px;width:100%;">

<h2 class="text-center mb-4">

Forgot Password

</h2><div class="text-end mb-3"><a href="login.php" class="btn btn-outline-secondary btn-sm">? Back to Login</a></div>

<?php if($error!=""){ ?>

<div class="alert alert-danger"><?= $error ?></div>

<?php } ?>

<?php if($step==1){ ?>

<form method="POST">

<div class="mb-4">

<label>Username</label>

<input
class="form-control"
name="username"
required>

</div>

<button
class="btn btn-primary w-100"
name="find_user">

Continue

</button>

</form>

<?php } ?>

<?php if($step==2){ ?>

<form method="POST">

<input
type="hidden"
name="username"
value="<?= htmlspecialchars($user["username"]) ?>">

<div class="mb-3">

<label>Favorite Teacher</label>

<input
class="form-control"
name="teacher"
required>

</div>

<div class="mb-3">

<label>First School</label>

<input
class="form-control"
name="school"
required>

</div>

<div class="mb-3">

<label>Favorite Book</label>

<input
class="form-control"
name="book"
required>

</div>

<div class="mb-3">

<label>New Password</label>

<input
type="password"
class="form-control"
name="new_password"
required>

</div>

<div class="mb-4">

<label>Confirm Password</label>

<input
type="password"
class="form-control"
name="confirm_password"
required>

</div>

<button
class="btn btn-success w-100"
name="reset_password">

Reset Password

</button>

</form>

<?php } ?>

</div>

</div>

<?php include "includes/footer.php"; ?>



