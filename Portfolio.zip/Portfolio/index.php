<?php
require "config/load-data.php";

include "includes/header.php";
include "includes/navbar.php";
include "includes/loader.php";

include "includes/hero.php";
include "includes/stats-section.php";
include "includes/about.php";
include "includes/stats.php";
include "includes/services.php";
include "includes/skills.php";
include "includes/projects.php";
include "includes/experience-section.php";
include "includes/education-section.php";
include "includes/contact-section.php";

include "includes/footer.php";
?>

