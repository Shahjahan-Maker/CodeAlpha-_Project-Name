<?php
require "config/database.php";

$projects = $conn->query("SELECT * FROM projects ORDER BY id DESC LIMIT 6");
?>

<?php include "includes/header.php"; ?>
<?php include "includes/navbar.php"; ?>

<section class="hero" id="home">

<div class="container">

<div class="row align-items-center">

<div class="col-lg-7">

<h1>Hi, I'm <span>Shahjahan</span></h1>

<h2>Backend PHP Developer</h2>

<p>
I build secure, scalable and modern PHP & MySQL applications with beautiful user interfaces.
</p>

<a href="#projects" class="btn btn-main mt-3">
View My Work
</a>

</div>

<div class="col-lg-5 text-center">

<img
src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
class="img-fluid"
style="max-width:350px;">

</div>

</div>

</div>

</section>

<section id="projects">

<div class="container">

<div class="section-title">

<h2>Latest Projects</h2>

<p>Projects loaded directly from the database.</p>

</div>

<div class="row">

<?php while($project = $projects->fetch_assoc()){ ?>

<div class="col-lg-4 mb-4">

<div class="card-glass h-100">

<?php if(!empty($project["image"])){ ?>

<img
src="assets/uploads/<?= htmlspecialchars($project["image"]) ?>"
class="img-fluid rounded mb-3"
style="height:220px;width:100%;object-fit:cover;">

<?php } ?>

<h4><?= htmlspecialchars($project["title"]) ?></h4>

<p><?= htmlspecialchars($project["description"]) ?></p>

<p>

<strong>Technology:</strong>

<?= htmlspecialchars($project["technology"]) ?>

</p>

<div class="mt-3">

<?php if(!empty($project["github"])){ ?>

<a
href="<?= htmlspecialchars($project["github"]) ?>"
target="_blank"
class="btn btn-sm btn-dark">

GitHub

</a>

<?php } ?>

<?php if(!empty($project["demo"])){ ?>

<a
href="<?= htmlspecialchars($project["demo"]) ?>"
target="_blank"
class="btn btn-sm btn-primary">

Live Demo

</a>

<?php } ?>

</div>

</div>

</div>

<?php } ?>

</div>

</div>

</section>

<?php include "includes/footer.php"; ?>
