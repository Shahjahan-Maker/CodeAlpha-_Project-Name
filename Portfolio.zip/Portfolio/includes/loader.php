<div id="loader">

<div class="spinner-border text-primary"
style="width:4rem;height:4rem;">

</div>

</div>
