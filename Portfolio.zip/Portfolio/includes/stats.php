<section class="stats">

<div class="container">

<div class="row g-4">

<div class="col-lg-3 col-6">

<div class="stat-card">

<h2 class="counter"

data-target="<?= $conn->query("SELECT COUNT(*) c FROM projects")->fetch_assoc()["c"] ?>">

0

</h2>

<p>Projects</p>

</div>

</div>

<div class="col-lg-3 col-6">

<div class="stat-card">

<h2 class="counter"

data-target="<?= $conn->query("SELECT COUNT(*) c FROM skills")->fetch_assoc()["c"] ?>">

0

</h2>

<p>Skills</p>

</div>

</div>

<div class="col-lg-3 col-6">

<div class="stat-card">

<h2 class="counter"

data-target="<?= $conn->query("SELECT COUNT(*) c FROM experience")->fetch_assoc()["c"] ?>">

0

</h2>

<p>Experience</p>

</div>

</div>

<div class="col-lg-3 col-6">

<div class="stat-card">

<h2 class="counter"

data-target="<?= $conn->query("SELECT COUNT(*) c FROM education")->fetch_assoc()["c"] ?>">

0

</h2>

<p>Education</p>

</div>

</div>

</div>

</div>

</section>
