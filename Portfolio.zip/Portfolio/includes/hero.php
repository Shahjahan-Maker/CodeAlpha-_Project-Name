<section id="home" class="hero">

<div class="container">

<div class="row align-items-center">

<div class="col-lg-7 hero-content" data-aos="fade-right">

<h4>Hello, It's Me</h4>

<h1>

<?= htmlspecialchars($settings["fullname"]) ?>

</h1>

<h2>

<span id="typing"></span>

</h2>

<p>

<?= htmlspecialchars($settings["tagline"]) ?>

</p>

<div class="hero-buttons">

<a href="#contact" class="btn btn-primary">

Hire Me

</a>

<?php if(!empty($settings["resume"])){ ?>

<a
href="assets/uploads/resume/<?= htmlspecialchars($settings["resume"]) ?>"
download
class="btn btn-outline-info">

Download CV

</a>

<?php } ?>

</div>

<div class="hero-social">

<?php
$socials=[
["github","fab fa-github"],
["linkedin","fab fa-linkedin"],
["facebook","fab fa-facebook"],
["instagram","fab fa-instagram"]
];

foreach($socials as $social){

$key=$social[0];
$icon=$social[1];

if(!empty($settings[$key])){

echo "<a href='{$settings[$key]}' target='_blank'><i class='$icon'></i></a>";

}

}
?>

</div>

</div>

<div class="col-lg-5 text-center" data-aos="zoom-in">

<?php if(!empty($settings["profile_image"])){ ?>

<img
src="assets/uploads/profile/<?= htmlspecialchars($settings["profile_image"]) ?>"
class="hero-image floating">

<?php }else{ ?>

<img
src="https://ui-avatars.com/api/?name=<?= urlencode($settings["fullname"]) ?>&size=500&background=00ABF0&color=fff"
class="hero-image floating">

<?php } ?>

</div>

</div>

</div>

</section>
