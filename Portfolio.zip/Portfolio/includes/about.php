<section id="about" class="about">

<div class="container">

<div class="row align-items-center">

<div class="col-lg-5 text-center" data-aos="fade-right">

<?php if(!empty($settings["profile_image"])){ ?>

<img
src="assets/uploads/profile/<?= htmlspecialchars($settings["profile_image"]) ?>"
class="about-image">

<?php } else { ?>

<img
src="https://ui-avatars.com/api/?name=<?= urlencode($settings["fullname"]) ?>&size=500&background=00ABF0&color=fff"
class="about-image">

<?php } ?>

</div>

<div class="col-lg-7" data-aos="fade-left">

<h2 class="section-title">

About <span>Me</span>

</h2>

<h4 class="text-info mb-4">

<?= htmlspecialchars($settings["title"]) ?>

</h4>

<p>

<?= nl2br(htmlspecialchars($settings["about"])) ?>

</p>

<a href="#contact" class="btn btn-primary mt-4">

Let's Talk

</a>

</div>

</div>

</div>

</section>
