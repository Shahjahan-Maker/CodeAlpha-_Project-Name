<section id="contact" class="py-5 bg-dark text-white">

<div class="container">

<div class="text-center mb-5">
<h2>Contact Me</h2>
</div>

<?php if(isset($_GET["success"])) { ?>

<div class="alert alert-success">
Your message has been sent successfully.
</div>

<?php } ?>

<form action="contact.php" method="POST">

<div class="row">

<div class="col-md-6 mb-3">
<input class="form-control" name="name" placeholder="Your Name" required>
</div>

<div class="col-md-6 mb-3">
<input class="form-control" type="email" name="email" placeholder="Your Email" required>
</div>

</div>

<div class="mb-3">
<input class="form-control" name="subject" placeholder="Subject" required>
</div>

<div class="mb-3">
<textarea class="form-control" rows="6" name="message" placeholder="Message" required></textarea>
</div>

<button class="btn btn-primary">
Send Message
</button>

</form>

</div>

</section>
