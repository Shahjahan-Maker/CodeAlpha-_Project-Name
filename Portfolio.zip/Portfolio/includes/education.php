<section id="education" class="education">

<div class="container">

<div class="text-center mb-5">

<h2 class="section-title">

My <span>Education</span>

</h2>

</div>

<div class="timeline">

<?php while($edu=$education->fetch_assoc()){ ?>

<div class="timeline-item" data-aos="fade-up">

<div class="timeline-dot"></div>

<div class="timeline-content">

<h4>

<?= htmlspecialchars($edu["degree"]) ?>

</h4>

<h6 class="text-info">

<?= htmlspecialchars($edu["institution"]) ?>

</h6>

<p>

<?= $edu["start_year"] ?>

-

<?= $edu["end_year"] ?>

</p>

<p>

<?= htmlspecialchars($edu["field"]) ?>

</p>

</div>

</div>

<?php } ?>

</div>

</div>

</section>
