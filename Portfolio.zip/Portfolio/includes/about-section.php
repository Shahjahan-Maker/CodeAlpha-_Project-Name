<section id="about" class="py-5">

<div class="container">

<div class="text-center mb-5">

<h2>About Me</h2>

<p class="text-secondary">

Who I Am

</p>

</div>

<div class="row justify-content-center">

<div class="col-lg-8">

<div class="card-box">

<p class="lead">

<?= nl2br(htmlspecialchars($settings["about"])) ?>

</p>

</div>

</div>

</div>

</div>

</section>
