<section id="projects" class="projects">

<div class="container">

<div class="text-center mb-5">

<h2 class="section-title">

Latest <span>Projects</span>

</h2>

<p class="text-light">

Some of my recent work.

</p>

</div>

<div class="row g-4">

<?php while($project=$projects->fetch_assoc()){ ?>

<div class="col-lg-4 col-md-6">

<div class="project-card" data-aos="zoom-in">

<div class="position-relative">

<?php if(!empty($project["image"])){ ?>

<img

src="assets/uploads/<?= htmlspecialchars($project["image"]) ?>"

class="project-image">

<?php } else { ?>

<img

src="https://picsum.photos/600/400?random=<?= $project["id"] ?>"

class="project-image">

<?php } ?>

<div class="project-overlay">

<?php if(!empty($project["github"])){ ?>

<a

href="<?= htmlspecialchars($project["github"]) ?>"

target="_blank"

class="btn btn-dark">

<i class="fab fa-github"></i>

</a>

<?php } ?>

<?php if(!empty($project["demo"])){ ?>

<a

href="<?= htmlspecialchars($project["demo"]) ?>"

target="_blank"

class="btn btn-primary">

<i class="fas fa-globe"></i>

</a>

<?php } ?>

</div>

</div>

<div class="project-content">

<h4>

<?= htmlspecialchars($project["title"]) ?>

</h4>

<p>

<?= htmlspecialchars(substr($project["description"],0,120)) ?>...

</p>

<?php

$techs=explode(",",$project["technology"]);

foreach($techs as $tech){

?>

<span class="tech-badge">

<?= trim(htmlspecialchars($tech)) ?>

</span>

<?php } ?>

</div>

</div>

</div>

<?php } ?>

</div>

</div>

</section>
