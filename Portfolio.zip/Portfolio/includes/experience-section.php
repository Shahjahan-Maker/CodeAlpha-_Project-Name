<section id="experience" class="timeline-section py-5">

<div class="container">

<div class="text-center mb-5">

<span class="text-primary fw-bold">CAREER</span>

<h2 class="display-5 fw-bold">Experience</h2>

<p class="text-secondary">
My Professional Journey
</p>

</div>

<div class="timeline">

<?php while($exp=$experience->fetch_assoc()){ ?>

<div class="timeline-item">

<div class="timeline-dot"></div>

<div class="timeline-content">

<h4><?= htmlspecialchars($exp["position"]) ?></h4>

<h6 class="text-primary">

<?= htmlspecialchars($exp["company"]) ?>

</h6>

<small class="text-muted">

<?= date("M Y",strtotime($exp["start_date"])) ?>

�

<?= $exp["currently_working"] ? "Present" : date("M Y",strtotime($exp["end_date"])) ?>

</small>

<p class="mt-3">

<?= nl2br(htmlspecialchars($exp["description"])) ?>

</p>

</div>

</div>

<?php } ?>

</div>

</div>

</section>
