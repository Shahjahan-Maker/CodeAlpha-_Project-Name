<footer class="footer">

<div class="container text-center">

<p class="mb-0">

� <?= date("Y") ?> <?= htmlspecialchars($settings["fullname"]) ?>.
All Rights Reserved.

</p>

</div>

<button id="backToTop" class="btn btn-primary rounded-circle">

<i class="fas fa-arrow-up"></i>

</button>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="assets/js/aos.js"></script>

<script src="assets/js/typed.js"></script>

<?php include "includes/hero-titles-script.php"; ?>
<script src="assets/js/main.js"></script>

</body>

</html>

