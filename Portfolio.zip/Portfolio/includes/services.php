<section id="services" class="services">

<div class="container">

<div class="text-center mb-5">

<h2 class="section-title">

My <span>Services</span>

</h2>

</div>

<div class="row g-4">

<?php

$services=$conn->query("SELECT * FROM services");

while($service=$services->fetch_assoc()){

?>

<div class="col-lg-4">

<div class="service-card" data-aos="zoom-in">

<div class="service-icon">

<i class="fas <?= htmlspecialchars($service["icon"]) ?>"></i>

</div>

<h4>

<?= htmlspecialchars($service["title"]) ?>

</h4>

<p>

<?= htmlspecialchars($service["description"]) ?>

</p>

</div>

</div>

<?php } ?>

</div>

</div>

</section>
