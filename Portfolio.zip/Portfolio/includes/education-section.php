<section id="education" class="timeline-section py-5 bg-dark">

<div class="container">

<div class="text-center mb-5">

<span class="text-primary fw-bold">ACADEMICS</span>

<h2 class="display-5 fw-bold text-white">

Education

</h2>

<p class="text-secondary">

My Educational Background

</p>

</div>

<div class="timeline">

<?php while($edu=$education->fetch_assoc()){ ?>

<div class="timeline-item">

<div class="timeline-dot"></div>

<div class="timeline-content">

<h4><?= htmlspecialchars($edu["degree"]) ?></h4>

<h6 class="text-info">

<?= htmlspecialchars($edu["institution"]) ?>

</h6>

<small class="text-muted">

<?= $edu["start_year"] ?>

�

<?= $edu["end_year"] ?>

</small>

<p class="mt-3">

<?= htmlspecialchars($edu["field"]) ?>

</p>

<p>

<?= nl2br(htmlspecialchars($edu["description"])) ?>

</p>

</div>

</div>

<?php } ?>

</div>

</div>

</section>
