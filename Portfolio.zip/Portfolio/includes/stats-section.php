<section class="py-5">

<div class="container">

<div class="row text-center">

<div class="col-md-3">

<div class="card p-4">

<h1 class="counter" data-target="<?= $conn->query("SELECT COUNT(*) c FROM projects")->fetch_assoc()["c"] ?>">0</h1>

<p>Projects</p>

</div>

</div>

<div class="col-md-3">

<div class="card p-4">

<h1 class="counter" data-target="<?= $conn->query("SELECT COUNT(*) c FROM skills")->fetch_assoc()["c"] ?>">0</h1>

<p>Skills</p>

</div>

</div>

<div class="col-md-3">

<div class="card p-4">

<h1 class="counter" data-target="<?= $conn->query("SELECT COUNT(*) c FROM experience")->fetch_assoc()["c"] ?>">0</h1>

<p>Experience</p>

</div>

</div>

<div class="col-md-3">

<div class="card p-4">

<h1 class="counter" data-target="<?= $conn->query("SELECT COUNT(*) c FROM education")->fetch_assoc()["c"] ?>">0</h1>

<p>Education</p>

</div>

</div>

</div>

</div>

</section>
