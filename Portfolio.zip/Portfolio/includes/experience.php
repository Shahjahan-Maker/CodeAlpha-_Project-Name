<section id="experience" class="experience">

<div class="container">

<div class="text-center mb-5">

<h2 class="section-title">

My <span>Experience</span>

</h2>

</div>

<div class="timeline">

<?php while($exp=$experience->fetch_assoc()){ ?>

<div class="timeline-item" data-aos="fade-up">

<div class="timeline-dot"></div>

<div class="timeline-content">

<h4>

<?= htmlspecialchars($exp["position"]) ?>

</h4>

<h6 class="text-info">

<?= htmlspecialchars($exp["company"]) ?>

</h6>

<p>

<?= date("M Y",strtotime($exp["start_date"])) ?>

-

<?= $exp["currently_working"] ? "Present" : date("M Y",strtotime($exp["end_date"])) ?>

</p>

<p>

<?= nl2br(htmlspecialchars($exp["description"])) ?>

</p>

</div>

</div>

<?php } ?>

</div>

</div>

</section>
