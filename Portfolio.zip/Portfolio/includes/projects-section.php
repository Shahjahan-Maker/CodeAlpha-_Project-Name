<section id="projects" class="projects-section py-5">

<div class="container">

<div class="text-center mb-5">

<span class="hero-badge">
MY WORK
</span>

<h2 class="display-4 fw-bold">
Featured Projects
</h2>

<p class="text-secondary">
A selection of projects I've built using modern technologies.
</p>

</div>

<div class="row g-4">

<?php while($project=$projects->fetch_assoc()){ ?>

<div class="col-lg-4 col-md-6">

<div class="project-card">

<div class="project-image-wrapper">

<?php if(!empty($project["image"])){ ?>

<img
src="assets/uploads/<?= htmlspecialchars($project["image"]) ?>"
class="project-image">

<?php } else { ?>

<div class="project-placeholder">

<i class="fas fa-laptop-code fa-4x"></i>

</div>

<?php } ?>

<div class="project-overlay">

<?php if(!empty($project["github"])){ ?>

<a
href="<?= htmlspecialchars($project["github"]) ?>"
target="_blank"
class="btn btn-dark">

<i class="fab fa-github"></i>

</a>

<?php } ?>

<?php if(!empty($project["demo"])){ ?>

<a
href="<?= htmlspecialchars($project["demo"]) ?>"
target="_blank"
class="btn btn-primary">

<i class="fas fa-globe"></i>

</a>

<?php } ?>

</div>

</div>

<div class="project-content">

<h3>

<?= htmlspecialchars($project["title"]) ?>

</h3>

<p>

<?= htmlspecialchars(substr($project["description"],0,120)) ?>...

</p>

<span class="tech-pill">

<?= htmlspecialchars($project["technology"]) ?>

</span>

</div>

</div>

</div>

<?php } ?>

</div>

</div>

</section>
