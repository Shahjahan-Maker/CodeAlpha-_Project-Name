<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title><?= htmlspecialchars($settings["fullname"]) ?> | <?= htmlspecialchars($settings["title"]) ?></title>

<meta name="description" content="<?= htmlspecialchars($settings["tagline"]) ?>">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">

<link href="assets/css/aos.css" rel="stylesheet">

<?php include "includes/theme.php"; ?>
<link href="assets/css/style.css" rel="stylesheet">

<link href="assets/css/responsive.css" rel="stylesheet">

</head>

<body style="<?php if($settings["background_type"]=="image" && !empty($settings["background_image"])){ ?>background:url('assets/uploads/backgrounds/<?= htmlspecialchars($settings["background_image"]) ?>') center center / cover fixed no-repeat;<?php }else{ ?>background:<?= htmlspecialchars($settings["background_color"]) ?>;<?php } ?>">




