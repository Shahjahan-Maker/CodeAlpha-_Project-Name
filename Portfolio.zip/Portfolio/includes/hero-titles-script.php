<?php

$heroTitles=[];

$query=$conn->query("SELECT title FROM hero_titles ORDER BY sort_order,id");

if($query){

while($row=$query->fetch_assoc()){

$heroTitles[]=$row["title"];

}

}

if(empty($heroTitles)){

$heroTitles=[
"Web Developer"
];

}

?>

<script>

window.heroTitles=<?= json_encode($heroTitles); ?>;

console.log("Hero Titles:",window.heroTitles);

</script>
