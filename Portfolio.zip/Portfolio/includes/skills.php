<section id="skills" class="skills">

<div class="container">

<div class="text-center mb-5">

<h2 class="section-title">

My <span>Skills</span>

</h2>

</div>

<div class="row">

<div class="col-lg-8 mx-auto">

<?php while($skill=$skills->fetch_assoc()){ ?>

<div class="skill">

<h5>

<span><?= htmlspecialchars($skill["skill_name"]) ?></span>

<span><?= $skill["percentage"] ?>%</span>

</h5>

<div class="skill-bar">

<div
class="skill-progress"
data-width="<?= $skill["percentage"] ?>%">

</div>

</div>

</div>

<?php } ?>

</div>

</div>

</div>

</section>
