<?php

if(!isset($settings)){
    return;
}

echo "<style>

:root{

--primary:".$settings["primary_color"].";
--secondary:".$settings["secondary_color"].";
--background:".$settings["background_color"].";
--navbar:".$settings["navbar_color"].";
--card:".$settings["card_color"].";
--text:".$settings["text_color"].";
--radius:".$settings["button_radius"]."px;
--font:'".$settings["font_family"]."',sans-serif;

}

body{

font-family:var(--font);
color:var(--text);

";

if($settings["background_type"]=="image" && !empty($settings["background_image"])){

echo "background:url(assets/uploads/backgrounds/".$settings["background_image"].") center center/cover fixed no-repeat;";

}else{

echo "background:var(--background);";

}

echo "

}

.navbar{

background:var(--navbar)!important;

}

.card,
.card-box,
.project-card,
.service-card,
.skill-card{

background:var(--card)!important;

}

.btn,
.btn-primary,
.btn-main{

background:var(--primary)!important;
border-color:var(--primary)!important;
border-radius:var(--radius)!important;

}

.btn:hover{

filter:brightness(.9);

}

a,
.nav-link:hover,
.hero span,
.section-title span{

color:var(--primary)!important;

}

</style>";

?>
