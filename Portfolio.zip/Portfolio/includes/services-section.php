<section id="services" class="py-5 bg-dark">

<div class="container">

<div class="text-center mb-5">

<span class="text-primary fw-bold">
SERVICES
</span>

<h2 class="display-5 fw-bold text-white">
What I Do
</h2>

</div>

<div class="row">

<?php

$services=$conn->query("SELECT * FROM services");

while($service=$services->fetch_assoc()){

?>

<div class="col-lg-4 mb-4">

<div class="service-card text-center">

<div class="icon">

<i class="fas <?= $service["icon"] ?>"></i>

</div>

<h4>

<?= htmlspecialchars($service["title"]) ?>

</h4>

<p>

<?= htmlspecialchars($service["description"]) ?>

</p>

</div>

</div>

<?php } ?>

</div>

</div>

</section>
