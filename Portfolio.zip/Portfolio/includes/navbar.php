<nav class="navbar navbar-expand-lg">

<div class="container">

<a class="navbar-brand" href="#home">

<?= htmlspecialchars($settings["fullname"]) ?>

</a>

<button
class="navbar-toggler text-white"
type="button"
data-bs-toggle="collapse"
data-bs-target="#navbarNav">

<i class="fas fa-bars"></i>

</button>

<div class="collapse navbar-collapse" id="navbarNav">

<ul class="navbar-nav ms-auto align-items-lg-center">

<li class="nav-item">
<a class="nav-link active" href="#home">Home</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#about">About</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#services">Services</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#skills">Skills</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#projects">Projects</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#experience">Experience</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#education">Education</a>
</li>

<li class="nav-item">
<a class="nav-link" href="#contact">Contact</a>
</li>

<li class="nav-item ms-lg-3">

<button
id="themeToggle"
class="btn btn-outline-info rounded-pill">

<i class="fas fa-moon"></i>

</button>

</li>

</ul>

</div>

</div>

</nav>
