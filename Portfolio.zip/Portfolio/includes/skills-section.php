<section id="skills" class="py-5 bg-dark text-light">

<div class="container">

<div class="text-center mb-5">

<h2 class="fw-bold">Technical Skills</h2>

<p class="text-secondary">
Technologies I work with
</p>

</div>

<div class="row">

<?php while($skill = $skills->fetch_assoc()){ ?>

<div class="col-lg-6 mb-4">

<h5>

<?= htmlspecialchars($skill["skill_name"]) ?>

<span class="float-end">

<?= $skill["percentage"] ?>%

</span>

</h5>

<div class="progress" style="height:10px;">

<div
class="progress-bar bg-info"
role="progressbar"
style="width:<?= $skill["percentage"] ?>%">
</div>

</div>

</div>

<?php } ?>

</div>

</div>

</section>
