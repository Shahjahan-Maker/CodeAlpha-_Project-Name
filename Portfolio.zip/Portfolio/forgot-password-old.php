<?php
session_start();
require "config/database.php";

$error="";
$success="";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$username=trim($_POST["username"]);
$teacher=trim($_POST["teacher"]);
$school=trim($_POST["school"]);
$book=trim($_POST["book"]);
$newPassword=$_POST["new_password"];
$confirmPassword=$_POST["confirm_password"];

$stmt=$conn->prepare("SELECT * FROM users WHERE username=?");
$stmt->bind_param("s",$username);
$stmt->execute();

$result=$stmt->get_result();

if($result->num_rows==0){

$error="Username not found.";

}else{

$user=$result->fetch_assoc();

if(
password_verify($teacher,$user["favorite_teacher"]) &&
password_verify($school,$user["first_school"]) &&
password_verify($book,$user["favorite_book"])
){

if($newPassword!=$confirmPassword){

$error="Passwords do not match.";

}else{

$hash=password_hash($newPassword,PASSWORD_DEFAULT);

$update=$conn->prepare("UPDATE users SET password=? WHERE id=?");
$update->bind_param("si",$hash,$user["id"]);
$update->execute();

$success="Password changed successfully. You can now login.";

}

}else{

$error="Security answers are incorrect.";

}

}

}

include "includes/header.php";
?>

<div class="container d-flex justify-content-center align-items-center" style="min-height:100vh;">

<div class="card-glass p-5" style="max-width:600px;width:100%;">

<h2 class="mb-4 text-center">

Forgot Password

</h2>

<?php if($error!=""){ ?>

<div class="alert alert-danger"><?= $error ?></div>

<?php } ?>

<?php if($success!=""){ ?>

<div class="alert alert-success"><?= $success ?></div>

<a href="login.php" class="btn btn-success w-100">

Go to Login

</a>

<?php } ?>

<form method="POST">

<div class="mb-3">
<label>Username</label>
<input class="form-control" name="username" required>
</div>

<div class="mb-3">
<label>Favorite Teacher</label>
<input class="form-control" name="teacher" required>
</div>

<div class="mb-3">
<label>First School</label>
<input class="form-control" name="school" required>
</div>

<div class="mb-3">
<label>Favorite Book</label>
<input class="form-control" name="book" required>
</div>

<div class="mb-3">
<label>New Password</label>
<input type="password" class="form-control" name="new_password" required>
</div>

<div class="mb-4">
<label>Confirm Password</label>
<input type="password" class="form-control" name="confirm_password" required>
</div>

<button class="btn btn-primary w-100">

Reset Password

</button>

</form>

</div>

</div>

<?php include "includes/footer.php"; ?>
