if(typeof AOS!=="undefined"){
AOS.init({
duration:900,
once:true
});
}

const toggle=document.getElementById("themeToggle");

if(localStorage.getItem("theme")=="light"){
document.body.classList.add("light-mode");
toggle.innerHTML='<i class="fas fa-sun"></i>';
}

toggle?.addEventListener("click",()=>{

document.body.classList.toggle("light-mode");

if(document.body.classList.contains("light-mode")){

localStorage.setItem("theme","light");
toggle.innerHTML='<i class="fas fa-sun"></i>';

}else{

localStorage.setItem("theme","dark");
toggle.innerHTML='<i class="fas fa-moon"></i>';

}

});

window.addEventListener("scroll",()=>{

const nav=document.querySelector(".navbar");

if(window.scrollY>80){

nav.classList.add("shadow");

}else{

nav.classList.remove("shadow");

}

});

document.querySelectorAll(".counter").forEach(counter=>{

const update=()=>{

const target=+counter.dataset.target;

const current=+counter.innerText;

const increment=Math.ceil(target/40);

if(current<target){

counter.innerText=current+increment;

setTimeout(update,40);

}else{

counter.innerText=target;

}

};

update();

});


window.addEventListener("load",()=>{

document.body.classList.add("loaded");

});


const sections=document.querySelectorAll("section");
const navLinks=document.querySelectorAll(".nav-link");

window.addEventListener("scroll",()=>{

let current="";

sections.forEach(section=>{

const top=section.offsetTop-120;

if(pageYOffset>=top){

current=section.id;

}

});

navLinks.forEach(link=>{

link.classList.remove("active");

if(link.getAttribute("href")=="#"+current){

link.classList.add("active");

}

});

});


if(document.getElementById("typing")){

if(document.querySelector("#typing") && typeof heroTitles!=="undefined"){



}

}


if(document.getElementById("typing")){

if(document.querySelector("#typing") && typeof heroTitles!=="undefined"){



}

}


document.querySelectorAll(".project-card").forEach(card=>{

card.addEventListener("mouseenter",()=>{

card.style.transform="translateY(-12px)";

});

card.addEventListener("mouseleave",()=>{

card.style.transform="translateY(0)";

});

});


const navbar=document.querySelector(".navbar");

window.addEventListener("scroll",()=>{

if(window.scrollY>50){

navbar.classList.add("scrolled");

}else{

navbar.classList.remove("scrolled");

}

});


if(document.querySelector("#typing")){

if(document.querySelector("#typing") && typeof heroTitles!=="undefined"){



}

}


document.querySelectorAll(".counter").forEach(counter=>{

const update=()=>{

const target=+counter.dataset.target;

const current=+counter.innerText;

const increment=Math.max(1,Math.ceil(target/40));

if(current<target){

counter.innerText=Math.min(current+increment,target);

requestAnimationFrame(update);

}

};

update();

});


const observer=new IntersectionObserver(entries=>{

entries.forEach(entry=>{

if(entry.isIntersecting){

entry.target.style.width=entry.target.dataset.width;

}

});

});

document.querySelectorAll(".skill-progress").forEach(bar=>{

observer.observe(bar);

});


document.querySelectorAll(".project-card").forEach(card=>{

card.addEventListener("mouseenter",()=>{

card.style.boxShadow="0 25px 60px rgba(0,171,240,.25)";

});

card.addEventListener("mouseleave",()=>{

card.style.boxShadow="0 15px 35px rgba(0,0,0,.25)";

});

});





document.addEventListener("DOMContentLoaded",function(){

if(typeof heroTitles!=="undefined" && heroTitles.length){

new Typed("#typing",{

strings:heroTitles,

typeSpeed:80,

backSpeed:40,

backDelay:2000,

startDelay:500,

smartBackspace:true,

loop:true,

showCursor:true,

cursorChar:"|"

});

}

});

