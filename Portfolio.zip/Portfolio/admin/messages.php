<?php
require "../config/auth.php";
require "../config/database.php";

$result = $conn->query("SELECT * FROM messages ORDER BY id DESC");

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2 class="mb-4">Messages</h2>

<table class="table table-dark table-hover">

<thead>

<tr>

<th>ID</th>

<th>Name</th>

<th>Email</th>

<th>Subject</th>

<th>Status</th>

<th>Date</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<?php while($row=$result->fetch_assoc()){ ?>

<tr>

<td><?= $row["id"] ?></td>

<td><?= htmlspecialchars($row["name"]) ?></td>

<td><?= htmlspecialchars($row["email"]) ?></td>

<td><?= htmlspecialchars($row["subject"]) ?></td>

<td>

<?php if($row["status"]=="Unread"){ ?>

<span class="badge bg-danger">Unread</span>

<?php } else { ?>

<span class="badge bg-success">Read</span>

<?php } ?>

</td>

<td><?= $row["created_at"] ?></td>

<td>

<a href="view-message.php?id=<?= $row["id"] ?>" class="btn btn-info btn-sm">

View

</a>

<a href="delete-message.php?id=<?= $row["id"] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this message?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<?php include "includes/footer.php"; ?>
