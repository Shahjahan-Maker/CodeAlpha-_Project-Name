<?php
require "../config/auth.php";
require "../config/database.php";

$id=(int)($_GET["id"] ?? 0);

$stmt=$conn->prepare("SELECT * FROM education WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();
$result=$stmt->get_result();
$row=$result->fetch_assoc();

if(!$row){
die("Education record not found.");
}

if($_SERVER["REQUEST_METHOD"]=="POST"){

$institution=$_POST["institution"];
$degree=$_POST["degree"];
$field=$_POST["field"];
$start_year=$_POST["start_year"];
$end_year=!empty($_POST["end_year"])?$_POST["end_year"]:NULL;
$description=$_POST["description"];

$stmt=$conn->prepare("UPDATE education SET institution=?,degree=?,field=?,start_year=?,end_year=?,description=? WHERE id=?");

$stmt->bind_param(
"sssissi",
$institution,
$degree,
$field,
$start_year,
$end_year,
$description,
$id
);

$stmt->execute();

header("Location: education.php");
exit();

}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2>Edit Education</h2>

<form method="POST">

<div class="mb-3">
<label>Institution</label>
<input class="form-control" name="institution" value="<?= htmlspecialchars($row["institution"]) ?>" required>
</div>

<div class="mb-3">
<label>Degree</label>
<input class="form-control" name="degree" value="<?= htmlspecialchars($row["degree"]) ?>" required>
</div>

<div class="mb-3">
<label>Field</label>
<input class="form-control" name="field" value="<?= htmlspecialchars($row["field"]) ?>">
</div>

<div class="row">

<div class="col-md-6">
<label>Start Year</label>
<input class="form-control" type="number" name="start_year" value="<?= $row["start_year"] ?>" required>
</div>

<div class="col-md-6">
<label>End Year</label>
<input class="form-control" type="number" name="end_year" value="<?= $row["end_year"] ?>">
</div>

</div>

<div class="mt-3">
<label>Description</label>
<textarea class="form-control" rows="5" name="description"><?= htmlspecialchars($row["description"]) ?></textarea>
</div>

<button class="btn btn-success mt-4">

Update Education

</button>

<a href="education.php" class="btn btn-secondary mt-4">

Cancel

</a>

</form>

</div>

</div>

<?php include "includes/footer.php"; ?>
