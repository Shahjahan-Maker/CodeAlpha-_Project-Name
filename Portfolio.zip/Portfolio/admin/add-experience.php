<?php
require "../config/auth.php";
require "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $company = $_POST["company"];
    $position = $_POST["position"];
    $start_date = $_POST["start_date"];
    $end_date = !empty($_POST["end_date"]) ? $_POST["end_date"] : null;
    $currently_working = isset($_POST["currently_working"]) ? 1 : 0;
    $description = $_POST["description"];

    $stmt = $conn->prepare("INSERT INTO experience (company, position, start_date, end_date, currently_working, description) VALUES (?, ?, ?, ?, ?, ?)");

    $stmt->bind_param(
        "ssssis",
        $company,
        $position,
        $start_date,
        $end_date,
        $currently_working,
        $description
    );

    $stmt->execute();

    header("Location: experience.php");
    exit();
}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2>Add Experience</h2>

<form method="POST">

<div class="mb-3">
<label>Company</label>
<input type="text" name="company" class="form-control" required>
</div>

<div class="mb-3">
<label>Position</label>
<input type="text" name="position" class="form-control" required>
</div>

<div class="row">

<div class="col-md-6">
<label>Start Date</label>
<input type="date" name="start_date" class="form-control" required>
</div>

<div class="col-md-6">
<label>End Date</label>
<input type="date" name="end_date" class="form-control">
</div>

</div>

<div class="form-check mt-3">
<input class="form-check-input" type="checkbox" name="currently_working" value="1">
<label class="form-check-label">Currently Working Here</label>
</div>

<div class="mt-3">
<label>Description</label>
<textarea name="description" rows="5" class="form-control"></textarea>
</div>

<button type="submit" class="btn btn-success mt-4">
Save Experience
</button>

<a href="experience.php" class="btn btn-secondary mt-4">
Cancel
</a>

</form>

</div>

</div>

<?php include "includes/footer.php"; ?>
