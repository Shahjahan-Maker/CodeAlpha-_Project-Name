<?php
require "../config/auth.php";
require "../config/database.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$title=trim($_POST["title"]);
$sort_order=(int)$_POST["sort_order"];

$stmt=$conn->prepare("INSERT INTO hero_titles(title,sort_order) VALUES(?,?)");
$stmt->bind_param("si",$title,$sort_order);
$stmt->execute();

header("Location: hero-titles.php");
exit();

}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2 class="mb-4">Add Hero Title</h2>

<form method="POST">

<div class="mb-3">

<label>Title</label>

<input
type="text"
name="title"
class="form-control"
placeholder="Example: Web Developer"
required>

</div>

<div class="mb-4">

<label>Display Order</label>

<input
type="number"
name="sort_order"
class="form-control"
value="1"
required>

</div>

<button class="btn btn-success">

<i class="fas fa-save"></i>

Save Title

</button>

<a
href="hero-titles.php"
class="btn btn-secondary">

Cancel

</a>

</form>

</div>

</div>

<?php include "includes/footer.php"; ?>
