<?php
require "../config/auth.php";
require "../config/database.php";

$id=(int)($_GET["id"] ?? 0);

$stmt=$conn->prepare("SELECT * FROM hero_titles WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();

$titleData=$stmt->get_result()->fetch_assoc();

if(!$titleData){
die("Hero title not found.");
}

if($_SERVER["REQUEST_METHOD"]=="POST"){

$title=trim($_POST["title"]);
$sort_order=(int)$_POST["sort_order"];

$stmt=$conn->prepare("UPDATE hero_titles SET title=?,sort_order=? WHERE id=?");
$stmt->bind_param("sii",$title,$sort_order,$id);
$stmt->execute();

header("Location: hero-titles.php");
exit();

}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2 class="mb-4">

Edit Hero Title

</h2>

<form method="POST">

<div class="mb-3">

<label>Title</label>

<input
type="text"
name="title"
class="form-control"
value="<?= htmlspecialchars($titleData["title"]) ?>"
required>

</div>

<div class="mb-4">

<label>Display Order</label>

<input
type="number"
name="sort_order"
class="form-control"
value="<?= $titleData["sort_order"] ?>"
required>

</div>

<button class="btn btn-success">

Save Changes

</button>

<a
href="hero-titles.php"
class="btn btn-secondary">

Cancel

</a>

</form>

</div>

</div>

<?php include "includes/footer.php"; ?>

