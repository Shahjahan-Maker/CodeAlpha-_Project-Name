<?php
require "../config/auth.php";
require "../config/database.php";

$message="";
$error="";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$current=$_POST["current_password"];
$new=$_POST["new_password"];
$confirm=$_POST["confirm_password"];

$stmt=$conn->prepare("SELECT password FROM users WHERE id=?");
$stmt->bind_param("i",$_SESSION["user_id"]);
$stmt->execute();

$user=$stmt->get_result()->fetch_assoc();

if(!password_verify($current,$user["password"])){

$error="Current password is incorrect.";

}elseif($new!=$confirm){

$error="Passwords do not match.";

}else{

$hash=password_hash($new,PASSWORD_DEFAULT);

$stmt=$conn->prepare("UPDATE users SET password=? WHERE id=?");
$stmt->bind_param("si",$hash,$_SESSION["user_id"]);
$stmt->execute();

$message="Password updated successfully.";

}

}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2 class="mb-4">Change Password</h2>

<?php if($message!=""){ ?>

<div class="alert alert-success"><?= $message ?></div>

<?php } ?>

<?php if($error!=""){ ?>

<div class="alert alert-danger"><?= $error ?></div>

<?php } ?>

<form method="POST">

<div class="mb-3">

<label>Current Password</label>

<input
type="password"
name="current_password"
class="form-control"
required>

</div>

<div class="mb-3">

<label>New Password</label>

<input
type="password"
name="new_password"
class="form-control"
required>

</div>

<div class="mb-4">

<label>Confirm Password</label>

<input
type="password"
name="confirm_password"
class="form-control"
required>

</div>

<button class="btn btn-success">

Update Password

</button>

</form>

</div>

</div>

<?php include "includes/footer.php"; ?>
