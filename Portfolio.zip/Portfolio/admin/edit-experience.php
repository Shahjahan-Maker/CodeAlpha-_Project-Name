<?php
require "../config/auth.php";
require "../config/database.php";

$id = (int)($_GET["id"] ?? 0);

$stmt = $conn->prepare("SELECT * FROM experience WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if(!$row){
    die("Experience not found.");
}

if($_SERVER["REQUEST_METHOD"]=="POST"){

$stmt = $conn->prepare("UPDATE experience SET company=?, position=?, start_date=?, end_date=?, currently_working=?, description=? WHERE id=?");

$current = isset($_POST["currently_working"]) ? 1 : 0;

$stmt->bind_param(
"ssssisi",
$_POST["company"],
$_POST["position"],
$_POST["start_date"],
$_POST["end_date"],
$current,
$_POST["description"],
$id
);

$stmt->execute();

header("Location: experience.php");
exit;
}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2>Edit Experience</h2>

<form method="POST">

<div class="mb-3">
<label>Company</label>
<input type="text" class="form-control" name="company" value="<?= htmlspecialchars($row["company"]) ?>" required>
</div>

<div class="mb-3">
<label>Position</label>
<input type="text" class="form-control" name="position" value="<?= htmlspecialchars($row["position"]) ?>" required>
</div>

<div class="row">

<div class="col-md-6">
<label>Start Date</label>
<input type="date" class="form-control" name="start_date" value="<?= $row["start_date"] ?>" required>
</div>

<div class="col-md-6">
<label>End Date</label>
<input type="date" class="form-control" name="end_date" value="<?= $row["end_date"] ?>">
</div>

</div>

<div class="form-check mt-3">

<input
type="checkbox"
class="form-check-input"
name="currently_working"
value="1"
<?= $row["currently_working"] ? "checked" : "" ?>>

<label class="form-check-label">

Currently Working

</label>

</div>

<div class="mt-3">

<label>Description</label>

<textarea class="form-control" rows="5" name="description"><?= htmlspecialchars($row["description"]) ?></textarea>

</div>

<button class="btn btn-success mt-4">

Update Experience

</button>

<a href="experience.php" class="btn btn-secondary mt-4">

Cancel

</a>

</form>

</div>

</div>

<?php include "includes/footer.php"; ?>
