<?php
require "../config/auth.php";
require "../config/database.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){

    $skill=trim($_POST["skill_name"]);
    $percentage=(int)$_POST["percentage"];

    $stmt=$conn->prepare("INSERT INTO skills(skill_name,percentage) VALUES(?,?)");
    $stmt->bind_param("si",$skill,$percentage);
    $stmt->execute();

    header("Location: skills.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Skill</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-dark text-white">

<div class="container py-5">

<h2>Add Skill</h2>

<form method="POST">

<div class="mb-3">
<label>Skill Name</label>
<input type="text" name="skill_name" class="form-control" required>
</div>

<div class="mb-3">
<label>Percentage</label>
<input type="number" name="percentage" class="form-control" min="0" max="100" required>
</div>

<button class="btn btn-success">Save Skill</button>
<a href="skills.php" class="btn btn-secondary">Cancel</a>

</form>

</div>

</body>
</html>
