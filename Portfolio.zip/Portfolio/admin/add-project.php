<?php
require "../config/auth.php";
require "../config/database.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $title = trim($_POST["title"]);
    $description = trim($_POST["description"]);
    $technology = trim($_POST["technology"]);
    $github = trim($_POST["github"]);
    $demo = trim($_POST["demo"]);

    $imageName = "";

    if(isset($_FILES["image"]) && $_FILES["image"]["error"] == 0){

        $allowed = ["jpg","jpeg","png","webp"];

        $extension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));

        if(in_array($extension,$allowed)){

            $imageName = uniqid("project_").".".$extension;

            move_uploaded_file(
                $_FILES["image"]["tmp_name"],
                "../assets/uploads/".$imageName
            );

        }else{

            $message = "Only JPG, JPEG, PNG and WEBP images are allowed.";

        }

    }

    if($message==""){

        $stmt = $conn->prepare("INSERT INTO projects(title,description,technology,github,demo,image) VALUES(?,?,?,?,?,?)");

        $stmt->bind_param(
            "ssssss",
            $title,
            $description,
            $technology,
            $github,
            $demo,
            $imageName
        );

        if($stmt->execute()){
            header("Location: projects.php?success=1");
            exit();
        }else{
            $message = "Database error.";
        }

    }

}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Add Project</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#0f172a;
color:white;
}

.card{
background:#1e293b;
border:none;
border-radius:15px;
}

</style>

</head>

<body>

<div class="container py-5">

<div class="card p-4">

<h2>Add Project</h2>

<?php if($message!=""){ ?>

<div class="alert alert-danger">

<?= $message ?>

</div>

<?php } ?>

<form method="POST" enctype="multipart/form-data">

<div class="mb-3">

<label>Project Title</label>

<input
type="text"
name="title"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Description</label>

<textarea
name="description"
rows="5"
class="form-control"
required></textarea>

</div>

<div class="mb-3">

<label>Technology</label>

<input
type="text"
name="technology"
class="form-control">

</div>

<div class="mb-3">

<label>GitHub URL</label>

<input
type="url"
name="github"
class="form-control">

</div>

<div class="mb-3">

<label>Live Demo URL</label>

<input
type="url"
name="demo"
class="form-control">

</div>

<div class="mb-3">

<label>Project Image</label>

<input
type="file"
name="image"
accept=".jpg,.jpeg,.png,.webp"
class="form-control">

</div>

<button class="btn btn-success">

Save Project

</button>

<a href="projects.php" class="btn btn-secondary">

Cancel

</a>

</form>

</div>

</div>

</body>

</html>
