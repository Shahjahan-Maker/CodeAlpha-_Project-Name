document.addEventListener("DOMContentLoaded",()=>{

document.querySelectorAll(".card-box h2").forEach(counter=>{

const target=parseInt(counter.innerText)||0;

let count=0;

const speed=20;

const update=()=>{

if(count<target){

count++;

counter.innerText=count;

setTimeout(update,speed);

}else{

counter.innerText=target;

}

};

update();

});

});
