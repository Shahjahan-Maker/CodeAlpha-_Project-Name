<?php
require "../config/auth.php";
require "../config/database.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$institution=$_POST["institution"];
$degree=$_POST["degree"];
$field=$_POST["field"];
$start_year=$_POST["start_year"];
$end_year=!empty($_POST["end_year"])?$_POST["end_year"]:NULL;
$description=$_POST["description"];

$stmt=$conn->prepare("INSERT INTO education(institution,degree,field,start_year,end_year,description) VALUES(?,?,?,?,?,?)");

$stmt->bind_param(
"sssiss",
$institution,
$degree,
$field,
$start_year,
$end_year,
$description
);

$stmt->execute();

header("Location: education.php");

exit();

}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2>Add Education</h2>

<form method="POST">

<div class="mb-3">
<label>Institution</label>
<input type="text" name="institution" class="form-control" required>
</div>

<div class="mb-3">
<label>Degree</label>
<input type="text" name="degree" class="form-control" required>
</div>

<div class="mb-3">
<label>Field of Study</label>
<input type="text" name="field" class="form-control">
</div>

<div class="row">

<div class="col-md-6">
<label>Start Year</label>
<input type="number" min="1980" max="2100" name="start_year" class="form-control" required>
</div>

<div class="col-md-6">
<label>End Year</label>
<input type="number" min="1980" max="2100" name="end_year" class="form-control">
</div>

</div>

<div class="mt-3">

<label>Description</label>

<textarea
name="description"
rows="5"
class="form-control"></textarea>

</div>

<button class="btn btn-success mt-4">

Save Education

</button>

<a href="education.php" class="btn btn-secondary mt-4">

Cancel

</a>

</form>

</div>

</div>

<?php include "includes/footer.php"; ?>
