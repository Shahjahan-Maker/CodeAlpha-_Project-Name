<?php
require "../config/auth.php";
require "../config/database.php";

$result = $conn->query("SELECT * FROM projects ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Manage Projects</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#0f172a;
    color:white;
}

.table{
    color:white;
    vertical-align:middle;
}

img{
    border-radius:10px;
    object-fit:cover;
}

</style>

</head>

<body>

<div class="container py-5">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>Manage Projects</h2>

<a href="add-project.php" class="btn btn-success">
Add New Project
</a>

</div>

<?php if(isset($_GET["success"])) { ?>

<div class="alert alert-success">

Project saved successfully.

</div>

<?php } ?>

<table class="table table-dark table-hover align-middle">

<thead>

<tr>

<th>ID</th>
<th>Image</th>
<th>Title</th>
<th>Technology</th>
<th>Created</th>
<th width="170">Action</th>

</tr>

</thead>

<tbody>

<?php while($row = $result->fetch_assoc()){ ?>

<tr>

<td><?= $row["id"] ?></td>

<td>

<?php if(!empty($row["image"])){ ?>

<img
src="../assets/uploads/<?= htmlspecialchars($row["image"]) ?>"
width="90"
height="70">

<?php } else { ?>

<span class="text-secondary">No Image</span>

<?php } ?>

</td>

<td><?= htmlspecialchars($row["title"]) ?></td>

<td><?= htmlspecialchars($row["technology"]) ?></td>

<td><?= $row["created_at"] ?></td>

<td>

<a
href="edit-project.php?id=<?= $row["id"] ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a
href="delete-project.php?id=<?= $row["id"] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete this project?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

<a href="../dashboard.php" class="btn btn-secondary">

Back to Dashboard

</a>

</div>

</body>

</html>
