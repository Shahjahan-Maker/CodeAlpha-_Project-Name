<?php
require "../config/auth.php";
require "../config/database.php";

$id=(int)$_GET["id"];

if($_SERVER["REQUEST_METHOD"]=="POST"){

    $skill=trim($_POST["skill_name"]);
    $percentage=(int)$_POST["percentage"];

    $stmt=$conn->prepare("UPDATE skills SET skill_name=?,percentage=? WHERE id=?");
    $stmt->bind_param("sii",$skill,$percentage,$id);
    $stmt->execute();

    header("Location: skills.php");
    exit();
}

$stmt=$conn->prepare("SELECT * FROM skills WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();

$row=$stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Edit Skill</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-dark text-white">

<div class="container py-5">

<h2>Edit Skill</h2>

<form method="POST">

<div class="mb-3">
<label>Skill Name</label>
<input type="text" name="skill_name" class="form-control" value="<?= htmlspecialchars($row["skill_name"]) ?>" required>
</div>

<div class="mb-3">
<label>Percentage</label>
<input type="number" name="percentage" class="form-control" min="0" max="100" value="<?= $row["percentage"] ?>" required>
</div>

<button class="btn btn-warning">Update Skill</button>
<a href="skills.php" class="btn btn-secondary">Cancel</a>

</form>

</div>

</body>
</html>
