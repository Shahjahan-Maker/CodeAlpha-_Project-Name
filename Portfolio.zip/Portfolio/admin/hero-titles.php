<?php
require "../config/auth.php";
require "../config/database.php";

$result=$conn->query("SELECT * FROM hero_titles ORDER BY sort_order ASC,id ASC");

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>Hero Titles</h2>

<a href="add-hero-title.php" class="btn btn-primary">

<i class="fas fa-plus"></i>

Add New Title

</a>

</div>

<table class="table table-striped table-hover">

<thead>

<tr>

<th>ID</th>

<th>Title</th>

<th>Order</th>

<th width="180">Actions</th>

</tr>

</thead>

<tbody>

<?php while($row=$result->fetch_assoc()){ ?>

<tr>

<td><?= $row["id"] ?></td>

<td><?= htmlspecialchars($row["title"]) ?></td>

<td><?= $row["sort_order"] ?></td>

<td>

<a
href="edit-hero-title.php?id=<?= $row["id"] ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<a
href="delete-hero-title.php?id=<?= $row["id"] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete this title?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<?php include "includes/footer.php"; ?>
