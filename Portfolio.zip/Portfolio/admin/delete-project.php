<?php
require "../config/auth.php";
require "../config/database.php";

if(isset($_GET["id"])){

$id=(int)$_GET["id"];

$stmt=$conn->prepare("DELETE FROM projects WHERE id=?");

$stmt->bind_param("i",$id);

$stmt->execute();

}

header("Location: projects.php");

exit();
?>
