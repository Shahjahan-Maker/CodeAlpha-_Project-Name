<?php
require "../config/auth.php";
require "../config/database.php";

$result = $conn->query("SELECT * FROM experience ORDER BY id DESC");

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>Experience</h2>

<a href="add-experience.php" class="btn btn-primary">

<i class="fas fa-plus"></i>

Add Experience

</a>

</div>

<table class="table table-dark table-hover">

<thead>

<tr>

<th>ID</th>

<th>Company</th>

<th>Position</th>

<th>Duration</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<?php while($row = $result->fetch_assoc()){ ?>

<tr>

<td><?= $row["id"] ?></td>

<td><?= htmlspecialchars($row["company"]) ?></td>

<td><?= htmlspecialchars($row["position"]) ?></td>

<td>

<?= $row["start_date"] ?>

-

<?= $row["currently_working"] ? "Present" : $row["end_date"] ?>

</td>

<td>

<a href="edit-experience.php?id=<?= $row["id"] ?>" class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete-experience.php?id=<?= $row["id"] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this experience?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<?php include "includes/footer.php"; ?>
