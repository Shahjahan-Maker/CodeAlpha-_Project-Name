<?php
require "../config/auth.php";
require "../config/database.php";

$totalProjects = $conn->query("SELECT COUNT(*) total FROM projects")->fetch_assoc()['total'];
$totalSkills = $conn->query("SELECT COUNT(*) total FROM skills")->fetch_assoc()['total'];
$totalMessages = $conn->query("SELECT COUNT(*) total FROM messages")->fetch_assoc()['total'];

$recentProjects = $conn->query("SELECT * FROM projects ORDER BY id DESC LIMIT 5");
?>

<?php include "includes/header.php"; ?>
<?php include "includes/sidebar.php"; ?>
<?php include "includes/topbar.php"; ?>

<div class="container-fluid">

<div class="row g-4">

<div class="col-lg-4">
<div class="card-box">
<h6>Total Projects</h6>
<h2><?= $totalProjects ?></h2>
<p>Projects in Portfolio</p>
</div>
</div>

<div class="col-lg-4">
<div class="card-box">
<h6>Total Skills</h6>
<h2><?= $totalSkills ?></h2>
<p>Technical Skills</p>
</div>
</div>

<div class="col-lg-4">
<div class="card-box">
<h6>Messages</h6>
<h2><?= $totalMessages ?></h2>
<p>Contact Messages</p>
</div>
</div>

</div>

</div>

<?php include "includes/footer.php"; ?>
