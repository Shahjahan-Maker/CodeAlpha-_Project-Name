<?php
require "../config/auth.php";
require "../config/database.php";

$result=$conn->query("SELECT * FROM education ORDER BY id DESC");

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>Education</h2>

<a href="add-education.php" class="btn btn-primary">

<i class="fas fa-plus"></i>

Add Education

</a>

</div>

<table class="table table-dark table-hover">

<thead>

<tr>

<th>ID</th>

<th>Institution</th>

<th>Degree</th>

<th>Years</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<?php while($row=$result->fetch_assoc()){ ?>

<tr>

<td><?= $row["id"] ?></td>

<td><?= htmlspecialchars($row["institution"]) ?></td>

<td><?= htmlspecialchars($row["degree"]) ?></td>

<td><?= $row["start_year"] ?> - <?= $row["end_year"] ?></td>

<td>

<a href="edit-education.php?id=<?= $row["id"] ?>" class="btn btn-warning btn-sm">

Edit

</a>

<a href="delete-education.php?id=<?= $row["id"] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this education record?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<?php include "includes/footer.php"; ?>
