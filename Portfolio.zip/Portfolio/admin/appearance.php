<?php
require "../config/auth.php";
require "../config/database.php";

$message="";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$type=$_POST["background_type"];
$color=$_POST["background_color"];
$primary=$_POST["primary_color"];
$secondary=$_POST["secondary_color"];
$navbar=$_POST["navbar_color"];
$card=$_POST["card_color"];
$text=$_POST["text_color"];
$radius=$_POST["button_radius"];
$font=$_POST["font_family"];

$settings=$conn->query("SELECT * FROM settings WHERE id=1")->fetch_assoc();
$image=$settings["background_image"];

if(isset($_FILES["background_image"]) && $_FILES["background_image"]["error"]==0){

$ext=strtolower(pathinfo($_FILES["background_image"]["name"],PATHINFO_EXTENSION));

if(in_array($ext,["jpg","jpeg","png","webp"])){

$image=time()."_bg.".$ext;

move_uploaded_file(
$_FILES["background_image"]["tmp_name"],
"../assets/uploads/backgrounds/".$image
);

}

}

$stmt=$conn->prepare("UPDATE settings SET background_type=?,background_color=?,background_image=?,primary_color=?,secondary_color=?,navbar_color=?,card_color=?,text_color=?,button_radius=?,font_family=? WHERE id=1");
$stmt->bind_param("ssssssssis",$type,$color,$image,$primary,$secondary,$navbar,$card,$text,$radius,$font);
$stmt->execute();

$message="Appearance Updated Successfully.";

}

$settings=$conn->query("SELECT * FROM settings WHERE id=1")->fetch_assoc();

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2 class="mb-4">Website Appearance</h2>

<?php if($message!=""){ ?>

<div class="alert alert-success"><?= $message ?></div>

<?php } ?>

<form method="POST" enctype="multipart/form-data">

<div class="mb-3">

<label>Background Type</label>

<select name="background_type" class="form-control">

<option value="color" <?= $settings["background_type"]=="color"?"selected":"" ?>>Solid Color</option>

<option value="image" <?= $settings["background_type"]=="image"?"selected":"" ?>>Background Image</option>

</select>

</div>

<div class="mb-3">

<label>Background Color</label>

<input
type="color"
name="background_color"
class="form-control form-control-color"
value="<?= htmlspecialchars($settings["background_color"]) ?>">

</div>


<div class="mb-3">

<label>Primary Theme Color</label>

<input
type="color"
name="primary_color"
class="form-control form-control-color"
value="<?= htmlspecialchars($settings["primary_color"]) ?>">

</div>

<div class="mb-3">

<label>Secondary Theme Color</label>

<input
type="color"
name="secondary_color"
class="form-control form-control-color"
value="<?= htmlspecialchars($settings["secondary_color"]) ?>">

</div>

<div class="row">

<div class="col-md-4 mb-3">
<label>Navbar Color</label>
<input type="color"
name="navbar_color"
class="form-control form-control-color"
value="<?= htmlspecialchars($settings["navbar_color"]) ?>">
</div>

<div class="col-md-4 mb-3">
<label>Card Color</label>
<input type="color"
name="card_color"
class="form-control form-control-color"
value="<?= htmlspecialchars($settings["card_color"]) ?>">
</div>

<div class="col-md-4 mb-3">
<label>Text Color</label>
<input type="color"
name="text_color"
class="form-control form-control-color"
value="<?= htmlspecialchars($settings["text_color"]) ?>">
</div>

</div>

<div class="row">

<div class="col-md-6 mb-3">
<label>Button Radius</label>
<input type="range"
min="0"
max="50"
name="button_radius"
class="form-range"
value="<?= htmlspecialchars($settings["button_radius"]) ?>">
</div>

<div class="col-md-6 mb-3">
<label>Font Family</label>
<select name="font_family" class="form-control">
<option value="Poppins" <?= $settings["font_family"]=="Poppins"?"selected":"" ?>>Poppins</option>
<option value="Roboto" <?= $settings["font_family"]=="Roboto"?"selected":"" ?>>Roboto</option>
<option value="Inter" <?= $settings["font_family"]=="Inter"?"selected":"" ?>>Inter</option>
<option value="Montserrat" <?= $settings["font_family"]=="Montserrat"?"selected":"" ?>>Montserrat</option>
</select>
</div>

</div>
<div class="mb-4">

<label>Background Image</label>

<input
type="file"
name="background_image"
class="form-control"
accept="image/*">

</div>

<button class="btn btn-success">

Save Appearance

</button>

</form>

</div>

</div>

<?php include "includes/footer.php"; ?>





