<?php
require "../config/auth.php";
require "../config/database.php";

$userId=$_SESSION["user_id"];
$success="";
$error="";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$teacher=trim($_POST["teacher"]);
$school=trim($_POST["school"]);
$book=trim($_POST["book"]);

if($teacher=="" || $school=="" || $book==""){

$error="All fields are required.";

}else{

$teacherHash=password_hash($teacher,PASSWORD_DEFAULT);
$schoolHash=password_hash($school,PASSWORD_DEFAULT);
$bookHash=password_hash($book,PASSWORD_DEFAULT);

$stmt=$conn->prepare("UPDATE users SET favorite_teacher=?,first_school=?,favorite_book=? WHERE id=?");

$stmt->bind_param(
"sssi",
$teacherHash,
$schoolHash,
$bookHash,
$userId
);

$stmt->execute();

$success="Security answers saved successfully.";

}

}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2 class="mb-4">

Security Settings

</h2>

<?php if($success!=""){ ?>

<div class="alert alert-success">

<?= $success ?>

</div>

<?php } ?>

<?php if($error!=""){ ?>

<div class="alert alert-danger">

<?= $error ?>

</div>

<?php } ?>

<form method="POST">

<div class="mb-3">

<label>Favorite Teacher</label>

<input
type="text"
name="teacher"
class="form-control"
placeholder="Example: Tariq Sab"
required>

</div>

<div class="mb-3">

<label>First School</label>

<input
type="text"
name="school"
class="form-control"
placeholder="Example: Noor School System"
required>

</div>

<div class="mb-4">

<label>Favorite Book</label>

<input
type="text"
name="book"
class="form-control"
placeholder="Example: 48 Laws of Power"
required>

</div>

<button class="btn btn-success">

Save Security Answers

</button>

</form>

</div>

</div>

<?php include "includes/footer.php"; ?>
