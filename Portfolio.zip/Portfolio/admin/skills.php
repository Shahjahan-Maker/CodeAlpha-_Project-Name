<?php
require "../config/auth.php";
require "../config/database.php";

$skills = $conn->query("SELECT * FROM skills ORDER BY id ASC");
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Manage Skills</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#0f172a;
    color:#fff;
}

.table{
    color:#fff;
}

</style>

</head>

<body>

<div class="container py-5">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>Skills</h2>

<a href="add-skill.php" class="btn btn-success">
Add Skill
</a>

</div>

<table class="table table-dark table-hover">

<thead>

<tr>

<th>ID</th>
<th>Skill</th>
<th>Percentage</th>
<th>Action</th>

</tr>

</thead>

<tbody>

<?php while($row = $skills->fetch_assoc()){ ?>

<tr>

<td><?= $row["id"] ?></td>

<td><?= htmlspecialchars($row["skill_name"]) ?></td>

<td><?= $row["percentage"] ?>%</td>

<td>

<a href="edit-skill.php?id=<?= $row["id"] ?>" class="btn btn-warning btn-sm">
Edit
</a>

<a href="delete-skill.php?id=<?= $row["id"] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this skill?')">
Delete
</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

<a href="../dashboard.php" class="btn btn-secondary">
Dashboard
</a>

</div>

</body>

</html>
