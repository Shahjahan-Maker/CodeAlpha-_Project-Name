<?php

require "../config/auth.php";
require "../config/database.php";

$id=(int)($_GET["id"] ?? 0);

$stmt=$conn->prepare("DELETE FROM hero_titles WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();

header("Location: hero-titles.php");
exit();

?>
