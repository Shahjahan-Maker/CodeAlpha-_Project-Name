<?php
require "../config/auth.php";
require "../config/database.php";

if(!isset($_GET["id"])){
    header("Location: projects.php");
    exit();
}

$id = (int)$_GET["id"];

$stmt = $conn->prepare("SELECT * FROM projects WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows==0){
    die("Project not found.");
}

$project = $result->fetch_assoc();

$message="";

if($_SERVER["REQUEST_METHOD"]=="POST"){

    $title = trim($_POST["title"]);
    $description = trim($_POST["description"]);
    $technology = trim($_POST["technology"]);
    $github = trim($_POST["github"]);
    $demo = trim($_POST["demo"]);

    $stmt = $conn->prepare("UPDATE projects SET title=?, description=?, technology=?, github=?, demo=? WHERE id=?");
    $stmt->bind_param("sssssi",$title,$description,$technology,$github,$demo,$id);

    if($stmt->execute()){
        header("Location: projects.php?updated=1");
        exit();
    }else{
        $message="Update failed.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Edit Project</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#0f172a;
color:white;
}

.card{
background:#1e293b;
border:none;
border-radius:15px;
}

</style>

</head>

<body>

<div class="container py-5">

<div class="card p-4">

<h2>Edit Project</h2>

<?php if($message!=""){ ?>

<div class="alert alert-danger">
<?= $message ?>
</div>

<?php } ?>

<form method="POST">

<div class="mb-3">

<label>Project Title</label>

<input
type="text"
name="title"
class="form-control"
value="<?= htmlspecialchars($project["title"]) ?>"
required>

</div>

<div class="mb-3">

<label>Description</label>

<textarea
name="description"
rows="5"
class="form-control"
required><?= htmlspecialchars($project["description"]) ?></textarea>

</div>

<div class="mb-3">

<label>Technology</label>

<input
type="text"
name="technology"
class="form-control"
value="<?= htmlspecialchars($project["technology"]) ?>">

</div>

<div class="mb-3">

<label>GitHub URL</label>

<input
type="url"
name="github"
class="form-control"
value="<?= htmlspecialchars($project["github"]) ?>">

</div>

<div class="mb-3">

<label>Demo URL</label>

<input
type="url"
name="demo"
class="form-control"
value="<?= htmlspecialchars($project["demo"]) ?>">

</div>

<button class="btn btn-warning">

Update Project

</button>

<a href="projects.php" class="btn btn-secondary">

Cancel

</a>

</form>

</div>

</div>

</body>

</html>
