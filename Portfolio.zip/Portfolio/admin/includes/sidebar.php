<div class="sidebar">

<h2>
<i class="fas fa-user-shield"></i>
Portfolio CMS
</h2>

<a href="/Portfolio/admin/dashboard.php">
<i class="fas fa-chart-line"></i>
Dashboard
</a>

<a href="/Portfolio/admin/projects.php">
<i class="fas fa-folder-open"></i>
Projects
</a>

<a href="/Portfolio/admin/skills.php">
<i class="fas fa-code"></i>
Skills
</a>

<a href="/Portfolio/admin/experience.php">
<i class="fas fa-briefcase"></i>
Experience
</a>

<a href="/Portfolio/admin/education.php">
<i class="fas fa-graduation-cap"></i>
Education
</a>

<a href="/Portfolio/admin/messages.php">
<i class="fas fa-envelope"></i>
Messages
</a>

<a href="/Portfolio/admin/settings.php">
<i class="fas fa-gear"></i>
Settings
</a>

<a href="/Portfolio/admin/change-password.php">
<i class="fas fa-key"></i>
Change Password
</a>

<a href="/Portfolio/admin/security-settings.php">
<i class="fas fa-shield-alt"></i>
Security Settings
</a>

<a href="/Portfolio/admin/security-settings.php"><i class="fas fa-shield-alt"></i>Security Settings</a><a href="/Portfolio/admin/appearance.php"><i class="fas fa-palette"></i>Appearance</a><hr>

<a href="/Portfolio/logout.php">
<i class="fas fa-right-from-bracket"></i>
Logout
</a>

</div>









