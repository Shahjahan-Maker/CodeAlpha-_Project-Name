<div class="main">

<div class="topbar">

<div>

<h3>

Welcome,
<?php echo $_SESSION["fullname"]; ?>

</h3>

<p class="text-secondary">

Portfolio Management Dashboard

</p>

</div>

<div>

<span class="badge bg-success">

Online

</span>

</div>

</div>
