<?php
require "../config/auth.php";
require "../config/database.php";

$settings=$conn->query("SELECT * FROM settings WHERE id=1")->fetch_assoc();

if($_SERVER["REQUEST_METHOD"]=="POST"){

$fullname=$_POST["fullname"] ?? "";
$title=$_POST["title"] ?? "";
$tagline=$_POST["tagline"] ?? "";
$about=$_POST["about"] ?? "";
$email=$_POST["email"] ?? "";
$phone=$_POST["phone"] ?? "";
$location=$_POST["location"] ?? "";
$github=$_POST["github"] ?? "";
$linkedin=$_POST["linkedin"] ?? "";
$facebook=$_POST["facebook"] ?? "";
$instagram=$_POST["instagram"] ?? "";
$youtube=$_POST["youtube"] ?? "";

$profile_image=$settings["profile_image"];
$resume=$settings["resume"];

if(isset($_FILES["profile_image"]) && $_FILES["profile_image"]["error"]==0){

$ext=strtolower(pathinfo($_FILES["profile_image"]["name"],PATHINFO_EXTENSION));

if(in_array($ext,["jpg","jpeg","png","webp"])){

$profile_image=time()."_profile.".$ext;

move_uploaded_file(
$_FILES["profile_image"]["tmp_name"],
"../assets/uploads/profile/".$profile_image
);

}

}

if(isset($_FILES["resume"]) && $_FILES["resume"]["error"]==0){

$ext=strtolower(pathinfo($_FILES["resume"]["name"],PATHINFO_EXTENSION));

if($ext=="pdf"){

$resume=time()."_resume.pdf";

move_uploaded_file(
$_FILES["resume"]["tmp_name"],
"../assets/uploads/resume/".$resume
);

}

}

$stmt=$conn->prepare("UPDATE settings SET fullname=?,title=?,tagline=?,about=?,email=?,phone=?,location=?,github=?,linkedin=?,facebook=?,instagram=?,youtube=?,resume=?,profile_image=? WHERE id=1");

$stmt->bind_param(
"ssssssssssssss",
$fullname,
$title,
$tagline,
$about,
$email,
$phone,
$location,
$github,
$linkedin,
$facebook,
$instagram,
$youtube,
$resume,
$profile_image
);

$stmt->execute();

header("Location: settings.php?success=1");
exit();

}

$settings=$conn->query("SELECT * FROM settings WHERE id=1")->fetch_assoc();

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2 class="mb-4">Portfolio Settings</h2>

<?php if(isset($_GET["success"])){ ?>

<div class="alert alert-success">

Settings updated successfully.

</div>

<?php } ?>

<form method="POST" enctype="multipart/form-data">

<div class="row">

<div class="col-md-6 mb-3">

<label>Full Name</label>

<input
type="text"
class="form-control"
name="fullname"
value="<?= htmlspecialchars($settings["fullname"]) ?>">

</div>

<div class="col-md-6 mb-3">

<label>Professional Title</label>

<input
type="text"
class="form-control"
name="title"
value="<?= htmlspecialchars($settings["title"]) ?>">

</div>

</div>

<div class="mb-3">

<label>Tagline</label>

<input
type="text"
class="form-control"
name="tagline"
value="<?= htmlspecialchars($settings["tagline"]) ?>">

</div>

<div class="mb-3">

<label>About Me</label>

<textarea
class="form-control"
rows="6"
name="about"><?= htmlspecialchars($settings["about"]) ?></textarea>

</div>

<div class="row">

<div class="col-md-4 mb-3">

<label>Email</label>

<input
class="form-control"
name="email"
value="<?= htmlspecialchars($settings["email"]) ?>">

</div>

<div class="col-md-4 mb-3">

<label>Phone</label>

<input
class="form-control"
name="phone"
value="<?= htmlspecialchars($settings["phone"]) ?>">

</div>

<div class="col-md-4 mb-3">

<label>Location</label>

<input
class="form-control"
name="location"
value="<?= htmlspecialchars($settings["location"]) ?>">

</div>

</div>


<div class="mb-3">

<label>Typing Titles</label>

<textarea
class="form-control"
rows="3"
name="typing_titles"><?= htmlspecialchars($settings["typing_titles"]) ?></textarea>

<small class="text-muted">

Separate each title with a comma.

Example:

Web Developer,PHP Developer,Flutter Developer

</small>

</div>

<h4 class="mt-4">

Social Links

</h4>


<div class="mb-3">

<label>GitHub</label>

<input
class="form-control"
name="github"
value="<?= htmlspecialchars($settings["github"]) ?>">

</div>

<div class="mb-3">

<label>LinkedIn</label>

<input
class="form-control"
name="linkedin"
value="<?= htmlspecialchars($settings["linkedin"]) ?>">

</div>

<div class="mb-3">

<label>Facebook</label>

<input
class="form-control"
name="facebook"
value="<?= htmlspecialchars($settings["facebook"]) ?>">

</div>

<div class="mb-3">

<label>Instagram</label>

<input
class="form-control"
name="instagram"
value="<?= htmlspecialchars($settings["instagram"]) ?>">

</div>

<div class="mb-4">

<label>YouTube</label>

<input
class="form-control"
name="youtube"
value="<?= htmlspecialchars($settings["youtube"]) ?>">

</div>

<hr>

<h4 class="mb-3">

Portfolio Files

</h4>

<div class="row">

<div class="col-md-6 mb-4">

<label>Profile Image</label>

<input
type="file"
class="form-control"
name="profile_image"
accept="image/*">

<?php if(!empty($settings["profile_image"])){ ?>

<div class="mt-3">

<img
src="../assets/uploads/profile/<?= htmlspecialchars($settings["profile_image"]) ?>"
style="width:150px;height:150px;object-fit:cover;border-radius:12px;">

</div>

<?php } ?>

</div>

<div class="col-md-6 mb-4">

<label>Resume (PDF)</label>

<input
type="file"
class="form-control"
name="resume"
accept=".pdf">

<?php if(!empty($settings["resume"])){ ?>

<div class="mt-3">

<a
href="../assets/uploads/resume/<?= htmlspecialchars($settings["resume"]) ?>"
target="_blank"
class="btn btn-outline-success">

View Current Resume

</a>

</div>

<?php } ?>

</div>

</div>

<button class="btn btn-success">

<i class="fas fa-save"></i>

Save Settings

</button>

</form>

</div>

</div>

<?php include "includes/footer.php"; ?>


