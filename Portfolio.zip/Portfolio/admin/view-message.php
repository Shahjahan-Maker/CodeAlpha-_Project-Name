<?php
require "../config/auth.php";
require "../config/database.php";

$id=(int)($_GET["id"] ?? 0);

$conn->query("UPDATE messages SET status='Read' WHERE id=$id");

$stmt=$conn->prepare("SELECT * FROM messages WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();

$message=$stmt->get_result()->fetch_assoc();

if(!$message){
die("Message not found.");
}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="container-fluid">

<div class="card-box">

<h2>View Message</h2>

<hr>

<p><strong>Name:</strong> <?= htmlspecialchars($message["name"]) ?></p>

<p><strong>Email:</strong> <?= htmlspecialchars($message["email"]) ?></p>

<p><strong>Subject:</strong> <?= htmlspecialchars($message["subject"]) ?></p>

<p><strong>Date:</strong> <?= $message["created_at"] ?></p>

<hr>

<p><?= nl2br(htmlspecialchars($message["message"])) ?></p>

<hr>

<a href="messages.php" class="btn btn-secondary">

Back

</a>

</div>

</div>

<?php include "includes/footer.php"; ?>
