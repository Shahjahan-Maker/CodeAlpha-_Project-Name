<?php
session_start();
require "config/database.php";
$settings=$conn->query("SELECT * FROM settings WHERE id=1")->fetch_assoc();

$error = "";

if(isset($_SESSION["admin"])){
    header("Location: admin/dashboard.php");
    exit();
}

if($_SERVER["REQUEST_METHOD"]=="POST"){

    $username = trim($_POST["username"]);
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
    $stmt->bind_param("s",$username);
    $stmt->execute();

    $result = $stmt->get_result();

    if($result->num_rows==1){

        $user = $result->fetch_assoc();

        if(password_verify($password,$user["password"])){

            $_SESSION["admin"]=true;
            $_SESSION["user_id"]=$user["id"];
            $_SESSION["fullname"]=$user["fullname"];

            header("Location: admin/dashboard.php");
            exit();

        }else{
            $error="Incorrect password.";
        }

    }else{
        $error="User not found.";
    }
}
?>

<?php include "includes/header.php"; ?>

<div class="container d-flex justify-content-center align-items-center" style="min-height:100vh;">

<div class="card-glass p-5" style="max-width:450px;width:100%;">

<h2 class="text-center mb-4">Admin Login</h2>

<?php if($error!=""){ ?>

<div class="alert alert-danger">
<?php echo $error; ?>
</div>

<?php } ?>

<form method="POST">

<div class="mb-3">

<label>Username</label>

<input
type="text"
name="username"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Password</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<button class="btn btn-main w-100">

Login

</button>

</form><div class="text-center mt-3"><a href="forgot-password.php" class="text-info">Forgot Password?</a></div>

</div>

</div>

<?php include "includes/footer.php"; ?>


