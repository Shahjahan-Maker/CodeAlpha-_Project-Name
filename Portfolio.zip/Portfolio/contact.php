<?php
require "config/database.php";

if($_SERVER["REQUEST_METHOD"]!="POST"){
    header("Location: /Portfolio/index.php#contact");
    exit();
}

$stmt=$conn->prepare("INSERT INTO messages(name,email,subject,message) VALUES(?,?,?,?)");

$stmt->bind_param(
"ssss",
$_POST["name"],
$_POST["email"],
$_POST["subject"],
$_POST["message"]
);

$stmt->execute();

header("Location: /Portfolio/index.php?success=1#contact");
exit();
?>
