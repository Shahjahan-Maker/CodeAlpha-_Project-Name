<?php

require "database.php";

$settings = $conn->query("SELECT * FROM settings LIMIT 1")->fetch_assoc();

$skills = $conn->query("SELECT * FROM skills ORDER BY percentage DESC");

$projects = $conn->query("SELECT * FROM projects ORDER BY id DESC");

$experience = $conn->query("SELECT * FROM experience ORDER BY start_date DESC");

$education = $conn->query("SELECT * FROM education ORDER BY start_year DESC");

?>
