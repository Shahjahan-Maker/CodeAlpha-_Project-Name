<?php
session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: /Portfolio/login.php");
    exit();
}
?>
