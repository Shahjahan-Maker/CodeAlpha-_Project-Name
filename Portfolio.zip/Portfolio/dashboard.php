<?php

require "config/auth.php";
require "config/database.php";

$totalProjects = $conn->query("SELECT COUNT(*) total FROM projects")->fetch_assoc()['total'];
$totalSkills = $conn->query("SELECT COUNT(*) total FROM skills")->fetch_assoc()['total'];
$totalMessages = $conn->query("SELECT COUNT(*) total FROM messages")->fetch_assoc()['total'];

$recentProjects = $conn->query("SELECT * FROM projects ORDER BY id DESC LIMIT 5");

?>

<?php include "admin/includes/header.php"; ?>
<?php include "admin/includes/sidebar.php"; ?>
<?php include "admin/includes/topbar.php"; ?>

<div class="container-fluid">

<div class="row g-4">

<div class="col-lg-4">

<div class="card-box">

<h6><i class="fas fa-folder-open text-info"></i> Total Projects</h6>

<h2><?= $totalProjects ?></h2>

<p class="text-secondary">Projects in Portfolio</p>

</div>

</div>

<div class="col-lg-4">

<div class="card-box">

<h6><i class="fas fa-code text-success"></i> Total Skills</h6>

<h2><?= $totalSkills ?></h2>

<p class="text-secondary">Technical Skills</p>

</div>

</div>

<div class="col-lg-4">

<div class="card-box">

<h6><i class="fas fa-envelope text-warning"></i> Messages</h6>

<h2><?= $totalMessages ?></h2>

<p class="text-secondary">Contact Messages</p>

</div>

</div>

</div>

<div class="row mt-5">

<div class="col-lg-8">

<div class="card-box">

<h4 class="mb-4">

Recent Projects

</h4>

<table class="table table-dark table-hover">

<thead>

<tr>

<th>Image</th>
<th>Project</th>
<th>Technology</th>

</tr>

</thead>

<tbody>

<?php while($row = $recentProjects->fetch_assoc()){ ?>

<tr>

<td>

<?php if(!empty($row["image"])){ ?>

<img
src="assets/uploads/<?= htmlspecialchars($row["image"]) ?>"
width="70"
height="60"
style="object-fit:cover;">

<?php }else{ ?>

No Image

<?php } ?>

</td>

<td>

<?= htmlspecialchars($row["title"]) ?>

</td>

<td>

<?= htmlspecialchars($row["technology"]) ?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<div class="col-lg-4">

<div class="card-box">

<h4>

Portfolio Overview

</h4>

<canvas id="portfolioChart"></canvas>

</div>

</div>

</div>

</div>

<script>

const ctx=document.getElementById("portfolioChart");

new Chart(ctx,{

type:"doughnut",

data:{

labels:["Projects","Skills","Messages"],

datasets:[{

data:[
<?= $totalProjects ?>,
<?= $totalSkills ?>,
<?= $totalMessages ?>
]

}]

}

});

</script>

<?php include "admin/includes/footer.php"; ?>

