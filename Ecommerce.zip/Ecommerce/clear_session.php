﻿<?php

session_start();

$_SESSION = [];

session_destroy();

echo "<h2>Session Cleared Successfully</h2>";

echo '<a href="index.php">Go Back To Home</a>';

?>
