﻿document.addEventListener("DOMContentLoaded",function(){

console.log("ShopEase Loaded Successfully");

});
