﻿<?php

require_once "includes/header.php";
require_once "includes/navbar.php";

if(!isLoggedIn()){

    redirect("auth/login.php");

}

$stmt=$pdo->prepare("
SELECT
cart.id,
cart.quantity,
products.name,
products.price
FROM cart
JOIN products
ON cart.product_id=products.id
WHERE cart.user_id=?
");

$stmt->execute([
$_SESSION["user_id"]
]);

$items=$stmt->fetchAll();

$total=0;

foreach($items as $item){

$total+=$item["price"]*$item["quantity"];

}

?>

<section>

<div class="container">

<h1 class="section-title">

Checkout

</h1>

<?php if(empty($items)){ ?>

<div class="product-card">

<h3>Your cart is empty.</h3>

<a href="pages/shop.php" class="btn">

Continue Shopping

</a>

</div>

<?php } else { ?>

<div class="product-card">

<form action="php/place_order.php" method="POST">

<label>

Payment Method

</label>

<select
name="payment_method"
required>

<option value="Cash On Delivery">

Cash On Delivery

</option>

<option value="Credit Card">

Credit Card

</option>

<option value="Bank Transfer">

Bank Transfer

</option>

</select>

<br><br>

<h3>

Order Summary

</h3>

<hr>

<?php foreach($items as $item){ ?>

<p>

<?php echo htmlspecialchars($item["name"]); ?>

×

<?php echo $item["quantity"]; ?>

=

<?php echo money($item["price"]*$item["quantity"]); ?>

</p>

<?php } ?>

<hr>

<h2>

Grand Total

<?php echo money($total); ?>

</h2>

<br>

<button
class="btn"
type="submit">

Place Order

</button>

</form>

</div>

<?php } ?>

</div>

</section>

<?php

require_once "includes/footer.php";

?>
