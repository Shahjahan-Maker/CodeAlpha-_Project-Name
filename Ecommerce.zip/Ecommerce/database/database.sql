﻿
CREATE DATABASE IF NOT EXISTS shopease;

USE shopease;

CREATE TABLE users(

id INT AUTO_INCREMENT PRIMARY KEY,

fullname VARCHAR(150) NOT NULL,

email VARCHAR(150) UNIQUE NOT NULL,

phone VARCHAR(30),

password VARCHAR(255) NOT NULL,

role ENUM('customer','admin') DEFAULT 'customer',

status TINYINT DEFAULT 1,

created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);

CREATE TABLE categories(

id INT AUTO_INCREMENT PRIMARY KEY,

name VARCHAR(100) NOT NULL,

image VARCHAR(255),

created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);

CREATE TABLE products(

id INT AUTO_INCREMENT PRIMARY KEY,

category_id INT,

name VARCHAR(255) NOT NULL,

description TEXT,

price DECIMAL(10,2) NOT NULL,

stock INT DEFAULT 0,

image VARCHAR(255),

created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

FOREIGN KEY(category_id) REFERENCES categories(id)

);

CREATE TABLE cart(

id INT AUTO_INCREMENT PRIMARY KEY,

user_id INT,

product_id INT,

quantity INT DEFAULT 1,

created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

FOREIGN KEY(user_id) REFERENCES users(id),

FOREIGN KEY(product_id) REFERENCES products(id)

);

CREATE TABLE orders(

id INT AUTO_INCREMENT PRIMARY KEY,

user_id INT,

total DECIMAL(10,2),

status ENUM('Pending','Processing','Completed','Cancelled') DEFAULT 'Pending',

created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

FOREIGN KEY(user_id) REFERENCES users(id)

);

CREATE TABLE order_items(

id INT AUTO_INCREMENT PRIMARY KEY,

order_id INT,

product_id INT,

quantity INT,

price DECIMAL(10,2),

FOREIGN KEY(order_id) REFERENCES orders(id),

FOREIGN KEY(product_id) REFERENCES products(id)

);

CREATE TABLE reviews(

id INT AUTO_INCREMENT PRIMARY KEY,

product_id INT,

user_id INT,

rating INT,

review TEXT,

created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

FOREIGN KEY(product_id) REFERENCES products(id),

FOREIGN KEY(user_id) REFERENCES users(id)

);

CREATE TABLE contacts(

id INT AUTO_INCREMENT PRIMARY KEY,

name VARCHAR(150),

email VARCHAR(150),

subject VARCHAR(255),

message TEXT,

created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);

INSERT INTO categories(name) VALUES
('Electronics'),
('Fashion'),
('Shoes'),
('Accessories'),
('Home'),
('Sports');

INSERT INTO users(fullname,email,phone,password,role)
VALUES
(
'Administrator',
'admin@shopease.com',
'0000000000',
'$2y$10$TKh8H1.P9JgQJ5l8QvQ2V.MfQYj8l0Yg5P8e6m7Fh5Qm2xYwzA9bK',
'admin'
);

