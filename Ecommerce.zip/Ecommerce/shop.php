﻿<?php

require_once "includes/database.php";
require_once "includes/header.php";

$stmt=$pdo->query("
SELECT *
FROM products
ORDER BY id DESC
");

$products=$stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">Shop Products</h1>

<div class="product-grid">

<?php foreach($products as $product): ?>

<div class="product-card">

<img
src="assets/images/products/<?php echo htmlspecialchars($product["image"]); ?>"
alt="<?php echo htmlspecialchars($product["name"]); ?>"
style="width:100%;height:220px;object-fit:cover;">

<h3>

<?php echo htmlspecialchars($product["name"]); ?>

</h3>

<p>

<?php echo htmlspecialchars($product["description"]); ?>

</p>

<p>

<strong>Category:</strong>

<?php echo htmlspecialchars($product["category"]); ?>

</p>

<p>

<strong>Stock:</strong>

<?php echo $product["stock"]; ?>

</p>

<h3>

$<?php echo number_format($product["price"],2); ?>

</h3>

<form
action="cart.php"
method="POST">

<input
type="hidden"
name="product_id"
value="<?php echo $product["id"]; ?>">

<button
type="submit"
name="add_to_cart"
class="btn">

Add To Cart

</button>

</form>

</div>

<?php endforeach; ?>

</div>

</section>

<?php

require_once "includes/footer.php";

?>

