﻿<?php

require_once "includes/header.php";
require_once "includes/navbar.php";
require_once "includes/database.php";

?>

<!-- HERO -->

<section class="hero">

<div class="container">

<h1>

Welcome To ShopEase

</h1>

<p>

Your One Stop Destination For Premium Shopping

</p>

<a href="pages/shop.php" class="btn">

Shop Now

</a>

</div>

</section>

<!-- FEATURED PRODUCTS -->

<section>

<div class="container">

<h2 class="section-title">

Featured Products

</h2>

<div class="product-grid">

<?php

$stmt=$pdo->query("SELECT * FROM products LIMIT 4");

while($product=$stmt->fetch()){

?>

<div class="product-card">

<img
src="assets/images/products/<?php echo htmlspecialchars($product['image']); ?>"
alt="<?php echo htmlspecialchars($product['name']); ?>">

<div class="product-info">

<h3>

<?php echo htmlspecialchars($product['name']); ?>

</h3>

<p>

<?php echo htmlspecialchars($product['description']); ?>

</p>

<h2>

<?php echo money($product['price']); ?>

</h2>

<a
href="pages/product.php?id=<?php echo $product['id']; ?>"
class="btn">

View Product

</a>

</div>

</div>

<?php

}

?>

</div>

</div>

</section>

<!-- WHY CHOOSE US -->

<section>

<div class="container">

<h2 class="section-title">

Why Shop With Us?

</h2>

<div class="product-grid">

<div class="product-card">

<div class="product-info">

<h3>

🚚 Fast Delivery

</h3>

<p>

Nationwide fast shipping.

</p>

</div>

</div>

<div class="product-card">

<div class="product-info">

<h3>

🔒 Secure Payments

</h3>

<p>

100% Secure Transactions.

</p>

</div>

</div>

<div class="product-card">

<div class="product-info">

<h3>

💬 24/7 Support

</h3>

<p>

Always here to help.

</p>

</div>

</div>

</div>

</div>

</section>

<?php

require_once "includes/footer.php";

?>
