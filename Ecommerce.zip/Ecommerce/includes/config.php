﻿<?php

// ==========================================
// Database Configuration
// ==========================================

define("DB_HOST","localhost");
define("DB_NAME","shopease");
define("DB_USER","root");
define("DB_PASS","");

// ==========================================
// Website Configuration
// ==========================================

define("SITE_NAME","ShopEase");
define("SITE_URL","http://localhost/Ecommerce");

date_default_timezone_set("Asia/Karachi");

?>
