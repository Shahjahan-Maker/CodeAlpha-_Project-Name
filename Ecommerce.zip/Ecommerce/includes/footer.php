﻿<footer class="footer">

<div class="container">

<p>

© <?php echo date("Y"); ?>

ShopEase. All Rights Reserved.

</p>

</div>

</footer>

<script src="/Ecommerce/assets/js/main.js"></script>

</body>

</html>
