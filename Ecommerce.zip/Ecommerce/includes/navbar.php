﻿<nav class="navbar">

<div class="container">

<a href="/Ecommerce/index.php" class="logo">

<i class="fa-solid fa-store"></i>

ShopEase

</a>

<ul class="nav-menu">

<li><a href="/Ecommerce/index.php">Home</a></li>

<li><a href="/Ecommerce/pages/shop.php">Shop</a></li>

<li><a href="/Ecommerce/pages/about.php">About</a></li>

<li><a href="/Ecommerce/pages/contact.php">Contact</a></li>

<?php if(isLoggedIn()){ ?>

<li><a href="/Ecommerce/pages/profile.php">Profile</a></li>

<li><a href="/Ecommerce/auth/logout.php">Logout</a></li>

<?php } else { ?>

<li><a href="/Ecommerce/auth/login.php">Login</a></li>

<li><a href="/Ecommerce/auth/register.php">Register</a></li>

<?php } ?>

</ul>

</div>

</nav>
