﻿<?php

if(session_status() === PHP_SESSION_NONE){
    session_start();
}

function clean($text){
    return htmlspecialchars(trim($text),ENT_QUOTES,"UTF-8");
}

function isLoggedIn(){
    return isset($_SESSION["user_id"]);
}

function money($amount){
    return "$".number_format($amount,2);
}

function redirect($page){
    header("Location: ".$page);
    exit();
}

?>
