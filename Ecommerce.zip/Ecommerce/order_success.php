﻿<?php

require_once "includes/header.php";
require_once "includes/navbar.php";

?>

<section>

<div class="container">

<div class="product-card" style="text-align:center;padding:60px;">

<h1 style="color:green;">

✅ Order Placed Successfully!

</h1>

<br>

<p>

Thank you for shopping with ShopEase.

</p>

<br>

<a href="pages/shop.php" class="btn">

Continue Shopping

</a>

</div>

</div>

</section>

<?php

require_once "includes/footer.php";

?>
