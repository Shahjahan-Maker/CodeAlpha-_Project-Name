﻿<?php

require_once "../includes/header.php";

if(isset($_SESSION["admin_id"])){

    header("Location: dashboard.php");
    exit();

}

?>

<section>

<div class="container">

<h1 class="section-title">

Admin Login

</h1>

<div class="product-card">

<form action="login.php" method="POST">

<label>Email</label>

<input
type="email"
name="email"
required>

<br><br>

<label>Password</label>

<input
type="password"
name="password"
required>

<br><br>

<button
class="btn"
type="submit">

Login

</button>

</form>

</div>

</div>

</section>

<?php

require_once "../includes/footer.php";

?>
