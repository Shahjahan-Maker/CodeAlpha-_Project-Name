﻿<?php

require_once "../includes/database.php";

session_start();

if(!isset($_SESSION["admin_id"])){
    header("Location:index.php");
    exit();
}

if(!isset($_GET["id"])){
    header("Location:products.php");
    exit();
}

$id=(int)$_GET["id"];

$stmt=$pdo->prepare("DELETE FROM products WHERE id=?");
$stmt->execute([$id]);

header("Location:products.php");
exit();

?>
