﻿<?php

require_once "../includes/database.php";
require_once "../includes/header.php";

if(!isset($_SESSION["admin_id"])){
    header("Location:index.php");
    exit();
}

$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalProducts = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$totalOrders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$totalRevenue = $pdo->query("SELECT IFNULL(SUM(total_amount),0) FROM orders")->fetchColumn();

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">Admin Dashboard</h1>

<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-top:40px;">

<div class="product-card" style="text-align:center;">
<h2><?php echo $totalUsers; ?></h2>
<p>Total Users</p>
</div>

<div class="product-card" style="text-align:center;">
<h2><?php echo $totalProducts; ?></h2>
<p>Total Products</p>
</div>

<div class="product-card" style="text-align:center;">
<h2><?php echo $totalOrders; ?></h2>
<p>Total Orders</p>
</div>

<div class="product-card" style="text-align:center;">
<h2>$<?php echo number_format($totalRevenue,2); ?></h2>
<p>Total Revenue</p>
</div>

</div>

<br><br>

<div class="product-card">

<h2>Quick Actions</h2>

<br>

<a class="btn" href="products.php">Manage Products</a>

<a class="btn" href="orders.php">Manage Orders</a>

<a class="btn" href="users.php">Manage Users</a>

<a class="btn" href="../index.php">Open Website</a>

<a class="btn" href="logout.php">Logout</a>

</div>

</section>

<?php require_once "../includes/footer.php"; ?>
