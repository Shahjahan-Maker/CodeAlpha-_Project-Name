﻿<?php

require_once "../includes/database.php";
require_once "../includes/header.php";

if(!isset($_SESSION["admin_id"])){
    header("Location:index.php");
    exit();
}

$stmt=$pdo->query("
SELECT
orders.id,
users.fullname,
orders.total_amount,
orders.payment_method,
orders.status,
orders.created_at
FROM orders
JOIN users ON orders.user_id=users.id
ORDER BY orders.id DESC
");

$orders=$stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">All Orders</h1>

<table style="width:100%;border-collapse:collapse;background:#fff;">

<tr style="background:#2563eb;color:white;">
<th style="padding:12px;">ID</th>
<th>Customer</th>
<th>Total</th>
<th>Payment</th>
<th>Status</th>
<th>Date</th>
<th>Action</th>
</tr>

<?php foreach($orders as $order){ ?>

<tr style="text-align:center;border-bottom:1px solid #ddd;">

<td><?php echo $order["id"]; ?></td>

<td><?php echo htmlspecialchars($order["fullname"]); ?></td>

<td>$<?php echo number_format($order["total_amount"],2); ?></td>

<td><?php echo htmlspecialchars($order["payment_method"]); ?></td>

<td><?php echo htmlspecialchars($order["status"]); ?></td>

<td><?php echo $order["created_at"]; ?></td>

<td>

<form action="update_order.php" method="POST">

<input
type="hidden"
name="id"
value="<?php echo $order["id"]; ?>">

<select name="status">

<option <?php if($order["status"]=="Pending") echo "selected"; ?>>Pending</option>

<option <?php if($order["status"]=="Processing") echo "selected"; ?>>Processing</option>

<option <?php if($order["status"]=="Shipped") echo "selected"; ?>>Shipped</option>

<option <?php if($order["status"]=="Delivered") echo "selected"; ?>>Delivered</option>

</select>

<button class="btn" type="submit">

Update

</button>

</form>

</td>

</tr>

<?php } ?>

</table>

<br>

<a href="dashboard.php" class="btn">Back To Dashboard</a>

</section>

<?php require_once "../includes/footer.php"; ?>

