﻿<?php

require_once "../includes/database.php";
require_once "../includes/functions.php";

if($_SERVER["REQUEST_METHOD"]!="POST"){
    header("Location:index.php");
    exit();
}

$email=trim($_POST["email"]);
$password=$_POST["password"];

$stmt=$pdo->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
$stmt->execute([$email]);

$user=$stmt->fetch(PDO::FETCH_ASSOC);

if(
    $user &&
    $user["email"]==="admin@shopease.com" &&
    password_verify($password,$user["password"])
){

    $_SESSION["admin_id"]=$user["id"];
    $_SESSION["admin_name"]=$user["fullname"];

    header("Location:dashboard.php");
    exit();

}

header("Location:index.php?error=Invalid Login");
exit();

?>
