﻿<?php

require_once "../includes/database.php";
require_once "../includes/header.php";

if(!isset($_SESSION["admin_id"])){
    header("Location:index.php");
    exit();
}

if(!isset($_GET["id"])){
    header("Location:products.php");
    exit();
}

$id=(int)$_GET["id"];

$stmt=$pdo->prepare("SELECT * FROM products WHERE id=?");
$stmt->execute([$id]);

$product=$stmt->fetch(PDO::FETCH_ASSOC);

if(!$product){
    header("Location:products.php");
    exit();
}

if($_SERVER["REQUEST_METHOD"]=="POST"){

$name=trim($_POST["name"]);
$description=trim($_POST["description"]);
$price=$_POST["price"];
$category=trim($_POST["category"]);
$stock=$_POST["stock"];
$image=trim($_POST["image"]);

$stmt=$pdo->prepare("
UPDATE products
SET
name=?,
description=?,
price=?,
category=?,
stock=?,
image=?
WHERE id=?
");

$stmt->execute([
$name,
$description,
$price,
$category,
$stock,
$image,
$id
]);

header("Location:products.php");
exit();

}

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">Edit Product</h1>

<div class="product-card">

<form method="POST">

<label>Product Name</label>
<input type="text" name="name"
value="<?php echo htmlspecialchars($product["name"]); ?>" required>

<br><br>

<label>Description</label>
<textarea name="description" required><?php echo htmlspecialchars($product["description"]); ?></textarea>

<br><br>

<label>Price</label>
<input type="number" step="0.01" name="price"
value="<?php echo $product["price"]; ?>" required>

<br><br>

<label>Category</label>
<input type="text" name="category"
value="<?php echo htmlspecialchars($product["category"]); ?>" required>

<br><br>

<label>Stock</label>
<input type="number" name="stock"
value="<?php echo $product["stock"]; ?>" required>

<br><br>

<label>Image Filename</label>
<input type="text" name="image"
value="<?php echo htmlspecialchars($product["image"]); ?>" required>

<br><br>

<button class="btn" type="submit">
Save Changes
</button>

<a href="products.php" class="btn">
Cancel
</a>

</form>

</div>

</section>

<?php require_once "../includes/footer.php"; ?>

