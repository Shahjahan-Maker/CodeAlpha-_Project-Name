﻿<?php

require_once "../includes/database.php";
require_once "../includes/header.php";

if(!isset($_SESSION["admin_id"])){
    header("Location:index.php");
    exit();
}

$products=$pdo->query("
SELECT *
FROM products
ORDER BY id DESC
")->fetchAll(PDO::FETCH_ASSOC);

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">Manage Products</h1>

<p style="margin-bottom:20px;">
<a href="add_product.php" class="btn">+ Add Product</a>
<a href="dashboard.php" class="btn">Dashboard</a>
</p>

<table style="width:100%;border-collapse:collapse;background:white;">

<tr style="background:#2563eb;color:white;">

<th style="padding:12px;">ID</th>
<th>Name</th>
<th>Price</th>
<th>Category</th>
<th>Stock</th>
<th>Action</th>

</tr>

<?php foreach($products as $product){ ?>

<tr style="text-align:center;border-bottom:1px solid #ddd;">

<td><?php echo $product["id"]; ?></td>

<td><?php echo htmlspecialchars($product["name"]); ?></td>

<td>$<?php echo number_format($product["price"],2); ?></td>

<td><?php echo htmlspecialchars($product["category"]); ?></td>

<td><?php echo $product["stock"]; ?></td>

<td>

<a
class="btn"
href="edit_product.php?id=<?php echo $product["id"]; ?>">
Edit
</a>

<a
class="btn btn-danger"
href="delete_product.php?id=<?php echo $product["id"]; ?>"
onclick="return confirm('Delete this product?')">
Delete
</a>

</td>

</tr>

<?php } ?>

</table>

</section>

<?php require_once "../includes/footer.php"; ?>



