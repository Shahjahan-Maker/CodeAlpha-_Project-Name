﻿<?php

require_once "../includes/database.php";
require_once "../includes/header.php";

if(!isset($_SESSION["admin_id"])){
    header("Location:index.php");
    exit();
}

if($_SERVER["REQUEST_METHOD"]=="POST"){

$name=trim($_POST["name"]);
$description=trim($_POST["description"]);
$price=$_POST["price"];
$category=trim($_POST["category"]);
$stock=$_POST["stock"];
$image=trim($_POST["image"]);

$stmt=$pdo->prepare("
INSERT INTO products
(name,description,price,category,stock,image)
VALUES(?,?,?,?,?,?)
");

$stmt->execute([
$name,
$description,
$price,
$category,
$stock,
$image
]);

header("Location:products.php");
exit();

}

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">Add Product</h1>

<div class="product-card">

<form method="POST">

<label>Product Name</label>
<input type="text" name="name" required>

<br><br>

<label>Description</label>
<textarea name="description" required></textarea>

<br><br>

<label>Price</label>
<input type="number" step="0.01" name="price" required>

<br><br>

<label>Category</label>
<input type="text" name="category" required>

<br><br>

<label>Stock</label>
<input type="number" name="stock" required>

<br><br>

<label>Image Filename</label>
<input type="text" name="image" placeholder="example.jpg" required>

<br><br>

<button class="btn" type="submit">
Add Product
</button>

<a href="products.php" class="btn">
Cancel
</a>

</form>

</div>

</section>

<?php require_once "../includes/footer.php"; ?>

