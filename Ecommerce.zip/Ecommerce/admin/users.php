﻿<?php

require_once "../includes/database.php";
require_once "../includes/header.php";

if(!isset($_SESSION["admin_id"])){
    header("Location:index.php");
    exit();
}

$stmt=$pdo->query("
SELECT
id,
fullname,
email,
phone,
created_at
FROM users
ORDER BY id DESC
");

$users=$stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">Registered Users</h1>

<table class="cart-table">

<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Phone</th>
<th>Joined</th>
</tr>

<?php foreach($users as $user): ?>

<tr>

<td><?php echo $user["id"]; ?></td>

<td><?php echo htmlspecialchars($user["fullname"]); ?></td>

<td><?php echo htmlspecialchars($user["email"]); ?></td>

<td><?php echo htmlspecialchars($user["phone"]); ?></td>

<td><?php echo $user["created_at"]; ?></td>

</tr>

<?php endforeach; ?>

</table>

<br>

<a href="dashboard.php" class="btn">
Back To Dashboard
</a>

</section>

<?php require_once "../includes/footer.php"; ?>

