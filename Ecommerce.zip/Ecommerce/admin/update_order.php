﻿<?php

require_once "../includes/database.php";
require_once "../includes/functions.php";

if(!isset($_SESSION["admin_id"])){
    header("Location:index.php");
    exit();
}

if($_SERVER["REQUEST_METHOD"]=="POST"){

    $id=(int)$_POST["id"];
    $status=$_POST["status"];

    $stmt=$pdo->prepare("UPDATE orders SET status=? WHERE id=?");
    $stmt->execute([$status,$id]);

}

header("Location:orders.php");
exit();

?>
