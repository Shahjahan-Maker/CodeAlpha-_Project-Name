﻿<?php

session_start();

if(!isset($_SESSION["user_id"])){

    header("Location: auth/login.php");
    exit();

}

require_once "includes/header.php";
require_once "includes/navbar.php";
require_once "includes/database.php";

$stmt = $pdo->prepare("
SELECT
cart.id,
cart.quantity,
products.id AS product_id,
products.name,
products.price,
products.image
FROM cart
INNER JOIN products
ON cart.product_id = products.id
WHERE cart.user_id=?
");

$stmt->execute([$_SESSION["user_id"]]);

$items = $stmt->fetchAll();

$total = 0;

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">Shopping Cart</h1>

<?php if(count($items)==0){ ?>

<div class="product-card" style="padding:40px;text-align:center;">

<h2>Your cart is empty.</h2>

<br>

<a href="pages/shop.php" class="btn">

Continue Shopping

</a>

</div>

<?php }else{ ?>

<table style="width:100%;background:#fff;border-radius:12px;overflow:hidden;">

<tr style="background:#2563eb;color:white;">

<th>Image</th>

<th>Product</th>

<th>Price</th>

<th>Quantity</th>

<th>Subtotal</th>

<th>Action</th>

</tr>

<?php foreach($items as $item){

$subtotal = $item["price"] * $item["quantity"];

$total += $subtotal;

?>

<tr style="text-align:center;">

<td>

<img
src="assets/images/products/<?php echo htmlspecialchars($item["image"]); ?>"
style="width:80px;">

</td>

<td>

<?php echo htmlspecialchars($item["name"]); ?>

</td>

<td>

<?php echo money($item["price"]); ?>

</td>

<td>

<?php echo $item["quantity"]; ?>

</td>

<td>

<?php echo money($subtotal); ?>

</td>

<td>

<a
href="php/remove_cart.php?id=<?php echo $item["id"]; ?>"
class="btn"
style="background:#dc3545;">

Remove

</a>

</td>

</tr>

<?php } ?>

</table>

<br>

<h2 style="text-align:right;">

Grand Total :
<?php echo money($total); ?>

</h2>

<div style="text-align:right;">

<a
href="pages/shop.php"
class="btn">

Continue Shopping

</a>

<a
href="checkout.php"
class="btn">

Proceed To Checkout

</a>

</div>

<?php } ?>

</section>

<?php

require_once "includes/footer.php";

?>
