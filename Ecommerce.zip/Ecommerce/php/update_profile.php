﻿<?php

session_start();

require_once "../includes/database.php";

if(!isset($_SESSION["user_id"])){

    header("Location: ../auth/login.php");
    exit();

}

if($_SERVER["REQUEST_METHOD"]!="POST"){

    header("Location: ../pages/profile.php");
    exit();

}

$fullname = trim($_POST["fullname"]);
$phone = trim($_POST["phone"]);

$stmt = $pdo->prepare("
UPDATE users
SET fullname=?, phone=?
WHERE id=?
");

$stmt->execute([
    $fullname,
    $phone,
    $_SESSION["user_id"]
]);

$_SESSION["fullname"] = $fullname;

header("Location: ../pages/profile.php?success=Profile Updated");

exit();

?>
