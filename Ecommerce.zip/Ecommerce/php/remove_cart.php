﻿<?php

session_start();

if(!isset($_SESSION["user_id"])){

    header("Location: ../auth/login.php");
    exit();

}

require_once "../includes/database.php";

if(!isset($_GET["id"])){

    header("Location: ../cart.php");
    exit();

}

$id = (int)$_GET["id"];

$stmt = $pdo->prepare("
DELETE FROM cart
WHERE id=?
AND user_id=?
");

$stmt->execute([
$id,
$_SESSION["user_id"]
]);

header("Location: ../cart.php");

exit();

?>
