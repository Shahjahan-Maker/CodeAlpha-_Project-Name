﻿<?php

session_start();

require_once "../includes/database.php";

if(!isset($_SESSION["user_id"])){

    header("Location: ../auth/login.php");
    exit();

}

if($_SERVER["REQUEST_METHOD"]!="POST"){

    header("Location: ../pages/shop.php");
    exit();

}

$userId = $_SESSION["user_id"];
$productId = (int)$_POST["product_id"];
$quantity = (int)$_POST["quantity"];

if($quantity < 1){

    $quantity = 1;

}

$stmt = $pdo->prepare("
SELECT * FROM cart
WHERE user_id=? AND product_id=?
");

$stmt->execute([
    $userId,
    $productId
]);

$item = $stmt->fetch();

if($item){

    $update = $pdo->prepare("
    UPDATE cart
    SET quantity = quantity + ?
    WHERE id=?
    ");

    $update->execute([
        $quantity,
        $item["id"]
    ]);

}else{

    $insert = $pdo->prepare("
    INSERT INTO cart
    (user_id,product_id,quantity)
    VALUES (?,?,?)
    ");

    $insert->execute([
        $userId,
        $productId,
        $quantity
    ]);

}

header("Location: ../cart.php");

exit();

?>
