﻿<?php

session_start();

require_once "../includes/database.php";

if(!isset($_SESSION["user_id"])){

    header("Location: ../auth/login.php");
    exit();

}

if($_SERVER["REQUEST_METHOD"]!="POST"){

    header("Location: ../pages/profile.php");
    exit();

}

$currentPassword = $_POST["current_password"];
$newPassword = $_POST["new_password"];
$confirmPassword = $_POST["confirm_password"];

$stmt = $pdo->prepare("SELECT password FROM users WHERE id=?");
$stmt->execute([$_SESSION["user_id"]]);

$user = $stmt->fetch();

if(!$user){

    header("Location: ../pages/profile.php?error=User Not Found");
    exit();

}

if(!password_verify($currentPassword,$user["password"])){

    header("Location: ../pages/profile.php?error=Current Password Is Incorrect");
    exit();

}

if($newPassword !== $confirmPassword){

    header("Location: ../pages/profile.php?error=New Passwords Do Not Match");
    exit();

}

$hashedPassword = password_hash($newPassword,PASSWORD_DEFAULT);

$update = $pdo->prepare("
UPDATE users
SET password=?
WHERE id=?
");

$update->execute([
    $hashedPassword,
    $_SESSION["user_id"]
]);

header("Location: ../pages/profile.php?success=Password Changed Successfully");

exit();

?>
