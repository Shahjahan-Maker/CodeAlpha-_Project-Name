﻿<?php

session_start();

if(!isset($_SESSION["user_id"])){

    header("Location: ../auth/login.php");
    exit();

}

require_once "../includes/database.php";

$user = $_SESSION["user_id"];
$payment = $_POST["payment_method"];

$stmt = $pdo->prepare("
SELECT
cart.product_id,
cart.quantity,
products.price
FROM cart
JOIN products
ON cart.product_id = products.id
WHERE cart.user_id = ?
");

$stmt->execute([$user]);

$items = $stmt->fetchAll();

if(empty($items)){

    header("Location: ../cart.php");
    exit();

}

$total = 0;

foreach($items as $item){

    $total += $item["price"] * $item["quantity"];

}

$stmt = $pdo->prepare("
INSERT INTO orders
(user_id,total_amount,payment_method,status)
VALUES(?,?,?,'Pending')
");

$stmt->execute([
$user,
$total,
$payment
]);

$order_id = $pdo->lastInsertId();

$stmtItem = $pdo->prepare("
INSERT INTO order_items
(order_id,product_id,quantity,price)
VALUES(?,?,?,?)
");

foreach($items as $item){

    $stmtItem->execute([
    $order_id,
    $item["product_id"],
    $item["quantity"],
    $item["price"]
    ]);

}

$stmt = $pdo->prepare("
DELETE FROM cart
WHERE user_id=?
");

$stmt->execute([$user]);

header("Location: ../order_success.php");

exit();

?>
