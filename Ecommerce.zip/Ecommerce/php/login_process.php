﻿<?php

session_start();

require_once "../includes/database.php";

if($_SERVER["REQUEST_METHOD"]!="POST"){

    header("Location: ../auth/login.php");
    exit();

}

$email = trim($_POST["email"]);
$password = $_POST["password"];

$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);

$user = $stmt->fetch();

if($user && password_verify($password,$user["password"])){

    $_SESSION["user_id"] = $user["id"];
    $_SESSION["fullname"] = $user["fullname"];
    $_SESSION["email"] = $user["email"];

    header("Location: ../index.php");
    exit();

}

header("Location: ../auth/login.php?error=Invalid Email Or Password");
exit();

?>
