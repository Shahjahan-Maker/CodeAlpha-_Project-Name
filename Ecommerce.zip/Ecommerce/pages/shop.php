﻿<?php

require_once "../includes/header.php";
require_once "../includes/navbar.php";
require_once "../includes/database.php";

?>

<div class="container">

<h1 class="section-title">

Shop

</h1>

<div class="product-grid">

<?php

$stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");

while($product = $stmt->fetch()){

?>

<div class="product-card">

<img src="../assets/images/products/<?php echo htmlspecialchars($product["image"]); ?>" alt="">

<div class="product-info">

<h3>

<?php echo htmlspecialchars($product["name"]); ?>

</h3>

<p>

<?php echo htmlspecialchars($product["description"]); ?>

</p>

<h2>

<?php echo money($product["price"]); ?>

</h2>

<a class="btn"

href="product.php?id=<?php echo $product["id"]; ?>">

View Details

</a>

</div>

</div>

<?php

}

?>

</div>

</div>

<?php

require_once "../includes/footer.php";

?>
