﻿<?php

require_once "../includes/header.php";

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">Contact Us</h1>

<div class="product-card">

<form>

<label>Full Name</label>

<input
type="text"
placeholder="Enter your full name"
required>

<br><br>

<label>Email</label>

<input
type="email"
placeholder="Enter your email"
required>

<br><br>

<label>Subject</label>

<input
type="text"
placeholder="Subject"
required>

<br><br>

<label>Message</label>

<textarea
rows="6"
placeholder="Write your message here..."
required></textarea>

<br><br>

<button
class="btn"
type="submit">

Send Message

</button>

<a
href="index.php"
class="btn">

Home

</a>

</form>

<hr style="margin:40px 0;">

<h2>Contact Information</h2>

<p><strong>Email:</strong> support@shopease.com</p>

<p><strong>Phone:</strong> +92 300 1234567</p>

<p><strong>Address:</strong> Islamabad, Pakistan</p>

<p><strong>Business Hours:</strong> Monday - Saturday | 9:00 AM - 6:00 PM</p>

</div>

</section>

<?php

require_once "../includes/footer.php";

?>

