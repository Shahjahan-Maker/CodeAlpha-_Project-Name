﻿<?php

session_start();

require_once "../includes/header.php";
require_once "../includes/navbar.php";
require_once "../includes/database.php";

if(!isset($_GET["id"]) || !is_numeric($_GET["id"])){

    header("Location: shop.php");
    exit();

}

$id = (int)$_GET["id"];

$stmt = $pdo->prepare("SELECT * FROM products WHERE id=?");
$stmt->execute([$id]);

$product = $stmt->fetch();

if(!$product){

    echo "<h2 style='text-align:center;padding:50px;'>Product Not Found</h2>";

    require_once "../includes/footer.php";
    exit();

}

?>

<section class="container" style="padding:60px 0;">

<div class="product-card" style="display:flex;gap:40px;flex-wrap:wrap;padding:30px;">

<div style="flex:1;min-width:300px;">

<img
src="../assets/images/products/<?php echo htmlspecialchars($product["image"]); ?>"
alt="<?php echo htmlspecialchars($product["name"]); ?>"
style="width:100%;border-radius:12px;">

</div>

<div style="flex:1;min-width:300px;">

<h1><?php echo htmlspecialchars($product["name"]); ?></h1>

<h2 style="color:#2563eb;">
<?php echo money($product["price"]); ?>
</h2>

<p style="margin:20px 0;">
<?php echo htmlspecialchars($product["description"]); ?>
</p>

<p>
<strong>Category:</strong>
<?php echo htmlspecialchars($product["category"]); ?>
</p>

<p>
<strong>Stock:</strong>
<?php echo htmlspecialchars($product["stock"]); ?>
</p>

<br>

<form action="../php/cart_process.php" method="POST">

<input
type="hidden"
name="product_id"
value="<?php echo $product["id"]; ?>">

<label>Quantity</label>

<input
type="number"
name="quantity"
value="1"
min="1"
max="<?php echo $product["stock"]; ?>"
style="width:100px;">

<br><br>

<button
type="submit"
class="btn">

Add To Cart

</button>

</form>

</div>

</div>

</section>

<?php

require_once "../includes/footer.php";

?>
