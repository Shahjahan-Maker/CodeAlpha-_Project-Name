﻿<?php

session_start();

if(!isset($_SESSION["user_id"])){

    header("Location: ../auth/login.php");
    exit();

}

require_once "../includes/header.php";
require_once "../includes/navbar.php";
require_once "../includes/database.php";

$stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$_SESSION["user_id"]]);

$user = $stmt->fetch();

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">My Profile</h1>

<?php if(isset($_GET["success"])){ ?>

<div style="background:#d4edda;color:#155724;padding:15px;border-radius:8px;margin-bottom:20px;">
<?php echo htmlspecialchars($_GET["success"]); ?>
</div>

<?php } ?>

<?php if(isset($_GET["error"])){ ?>

<div style="background:#f8d7da;color:#721c24;padding:15px;border-radius:8px;margin-bottom:20px;">
<?php echo htmlspecialchars($_GET["error"]); ?>
</div>

<?php } ?>

<div class="product-card" style="max-width:750px;margin:auto;padding:30px;">

<h2>Edit Profile</h2>

<form action="../php/update_profile.php" method="POST">

<label>Full Name</label>

<input
type="text"
name="fullname"
value="<?php echo htmlspecialchars($user["fullname"]); ?>"
required>

<br><br>

<label>Email</label>

<input
type="email"
value="<?php echo htmlspecialchars($user["email"]); ?>"
disabled>

<br><br>

<label>Phone</label>

<input
type="text"
name="phone"
value="<?php echo htmlspecialchars($user["phone"]); ?>"
required>

<br><br>

<button
type="submit"
class="btn">

Save Changes

</button>

</form>

<hr style="margin:40px 0;">

<h2>Change Password</h2>

<form action="../php/change_password.php" method="POST">

<label>Current Password</label>

<input
type="password"
name="current_password"
required>

<br><br>

<label>New Password</label>

<input
type="password"
name="new_password"
required>

<br><br>

<label>Confirm New Password</label>

<input
type="password"
name="confirm_password"
required>

<br><br>

<button
type="submit"
class="btn">

Change Password

</button>

</form>

</div>

</section>

<?php

require_once "../includes/footer.php";

?>
