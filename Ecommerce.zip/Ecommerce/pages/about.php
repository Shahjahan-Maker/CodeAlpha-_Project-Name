﻿<?php

require_once "../includes/header.php";

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">About ShopEase</h1>

<div class="product-card">

<h2>Welcome To ShopEase</h2>

<p>
ShopEase is a modern eCommerce platform developed to provide a fast, secure, and user-friendly online shopping experience. Customers can browse products, add items to their cart, and place orders easily from anywhere.
</p>

<br>

<h2>Our Mission</h2>

<p>
Our mission is to deliver quality products at affordable prices while providing excellent customer service and a smooth shopping experience.
</p>

<br>

<h2>Why Choose ShopEase?</h2>

<ul style="margin-left:25px;line-height:2;">
<li>High Quality Products</li>
<li>Secure Checkout</li>
<li>Fast Delivery</li>
<li>Easy Shopping Experience</li>
<li>24/7 Customer Support</li>
</ul>

<br>

<h2>Our Features</h2>

<ul style="margin-left:25px;line-height:2;">
<li>User Registration & Login</li>
<li>Product Search</li>
<li>Shopping Cart</li>
<li>Order Management</li>
<li>Admin Dashboard</li>
<li>Responsive Design</li>
</ul>

<br>

<div style="text-align:center;">

<a href="shop.php" class="btn">
Start Shopping
</a>

</div>

</div>

</section>

<?php

require_once "../includes/footer.php";

?>

