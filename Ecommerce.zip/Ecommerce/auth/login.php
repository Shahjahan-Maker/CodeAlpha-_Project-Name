﻿<?php

session_start();

if(isset($_SESSION["user_id"])){

    header("Location: ../index.php");
    exit();

}

require_once "../includes/header.php";
require_once "../includes/navbar.php";

?>

<section class="auth-box">

<div class="container">

<h2>Login</h2>

<?php

if(isset($_GET["error"])){

echo '<div class="alert alert-danger">'.htmlspecialchars($_GET["error"]).'</div>';

}

?>

<form action="../php/login_process.php" method="POST">

<input
type="email"
name="email"
placeholder="Email Address"
required>

<input
type="password"
name="password"
placeholder="Password"
required>

<button
type="submit"
class="btn">

Login

</button>

</form>

<p class="mt-2 text-center">

Don't have an account?

<a href="register.php">

Register Here

</a>

</p>

</div>

</section>

<?php

require_once "../includes/footer.php";

?>
