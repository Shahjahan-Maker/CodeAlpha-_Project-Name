﻿<?php

require_once "../includes/database.php";
require_once "../includes/header.php";

if(isset($_SESSION["user_id"])){
    header("Location: ../index.php");
    exit();
}

$error="";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$fullname=trim($_POST["fullname"]);
$email=trim($_POST["email"]);
$phone=trim($_POST["phone"]);
$password=$_POST["password"];
$confirm=$_POST["confirm_password"];

if($password!=$confirm){

$error="Passwords do not match.";

}else{

$stmt=$pdo->prepare("SELECT id FROM users WHERE email=?");
$stmt->execute([$email]);

if($stmt->fetch()){

$error="Email already registered.";

}else{

$hash=password_hash($password,PASSWORD_DEFAULT);

$stmt=$pdo->prepare("
INSERT INTO users
(fullname,email,phone,password)
VALUES(?,?,?,?)
");

$stmt->execute([
$fullname,
$email,
$phone,
$hash
]);

header("Location: login.php?success=Registration Successful");
exit();

}

}

}

?>

<section class="container" style="padding:60px 0;">

<h1 class="section-title">Create Account</h1>

<div class="product-card">

<?php if($error!=""): ?>

<p style="color:red;font-weight:bold;">
<?php echo $error; ?>
</p>

<br>

<?php endif; ?>

<form method="POST">

<label>Full Name</label>
<input type="text" name="fullname" required>

<br><br>

<label>Email</label>
<input type="email" name="email" required>

<br><br>

<label>Phone</label>
<input type="text" name="phone" required>

<br><br>

<label>Password</label>
<input type="password" name="password" required>

<br><br>

<label>Confirm Password</label>
<input type="password" name="confirm_password" required>

<br><br>

<button class="btn" type="submit">
Register
</button>

<a href="login.php" class="btn">
Login
</a>

</form>

</div>

</section>

<?php require_once "../includes/footer.php"; ?>
