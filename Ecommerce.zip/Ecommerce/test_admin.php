﻿<?php

require_once "includes/database.php";

$stmt=$pdo->prepare("SELECT password FROM users WHERE email=?");
$stmt->execute(["admin@shopease.com"]);

$hash=$stmt->fetchColumn();

echo "<h2>Password Hash</h2>";
echo "<pre>".$hash."</pre>";

echo "<h2>Verify admin123</h2>";

var_dump(password_verify("admin123",$hash));

?>
