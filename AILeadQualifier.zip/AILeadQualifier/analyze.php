<?php

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$ch = curl_init("http://localhost:5678/webhook/lead-analysis");

curl_setopt_array($ch,[
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_POST=>true,
    CURLOPT_HTTPHEADER=>["Content-Type: application/json"],
    CURLOPT_POSTFIELDS=>json_encode($data)
]);

$response = curl_exec($ch);

if(curl_errno($ch)){
    http_response_code(500);
    echo json_encode(["error"=>curl_error($ch)]);
    exit;
}

curl_close($ch);

$json = json_decode($response,true);

if(isset($json["text"])){
    echo $json["text"];
}
elseif(isset($json["output"])){
    echo $json["output"];
}
else{
    echo $response;
}
?>
