const analyzeBtn = document.getElementById("analyzeBtn");
const loading = document.getElementById("loading");

const company=document.getElementById("company");
const industry=document.getElementById("industry");
const products=document.getElementById("products");
const audience=document.getElementById("audience");
const usp=document.getElementById("usp");
const lead=document.getElementById("lead");

function resetUI(){

company.textContent="-";
industry.textContent="-";
products.textContent="-";
audience.textContent="-";
usp.textContent="-";
lead.textContent="-";

}

async function analyzeWebsite(){

const website=document.getElementById("website").value.trim();

if(!website){

alert("Please enter a website URL.");

return;

}

loading.style.display="block";

resetUI();

try{

const response=await fetch("analyze.php",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({
url:website
})

});

const responseData=await response.json();
const data=typeof responseData.text==="string"?JSON.parse(responseData.text):responseData;

console.log(data);

window.aiResult=data;

}
catch(err){

console.error(err);

alert("Unable to connect to n8n.");

loading.style.display="none";

}

}

analyzeBtn.addEventListener("click",analyzeWebsite);
function renderResult(data){

loading.style.display="none";

company.textContent=data.company_name ?? "Unknown";

industry.textContent=data.industry ?? "Unknown";

products.textContent=Array.isArray(data.services)
?data.services.join(", ")
:"N/A";

audience.textContent=data.target_clients ?? "Unknown";

usp.textContent=data.reason ?? "N/A";

lead.textContent=`${data.lead_type ?? "Unknown"} (${data.proofguard_score ?? 0}/100)`;

}

const oldAnalyze=analyzeWebsite;

analyzeWebsite=async function(){

const website=document.getElementById("website").value.trim();

if(!website){

alert("Please enter a website URL.");

return;

}

loading.style.display="block";

resetUI();

try{

const response=await fetch("analyze.php",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({
url:website
})

});

const responseData=await response.json();
const result=typeof responseData.text==="string"?JSON.parse(responseData.text):responseData;

console.log(result);

renderResult(result);

}
catch(error){

loading.style.display="none";

console.error(error);

alert("Connection to n8n failed.");

}

}

analyzeBtn.removeEventListener("click",oldAnalyze);

analyzeBtn.addEventListener("click",analyzeWebsite);



