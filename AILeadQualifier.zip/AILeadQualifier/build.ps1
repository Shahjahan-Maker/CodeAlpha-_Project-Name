$Project = "C:\xampp\htdocs\AILeadQualifier"

Write-Host ""
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host " AI Lead Qualifier Website Builder"
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host ""

$Folders = @(
"$Project\css",
"$Project\js",
"$Project\images",
"$Project\assets"
)

foreach($Folder in $Folders){

    if(!(Test-Path $Folder)){
        New-Item -ItemType Directory -Path $Folder | Out-Null
    }

}

$HTML = @'

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>AI Lead Qualifier</title>

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
rel="stylesheet">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
rel="stylesheet"
href="css/style.css">

</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">

<div class="container">

<a class="navbar-brand fw-bold"
href="#">

AI Lead Qualifier

</a>

<button
class="navbar-toggler"
data-bs-toggle="collapse"
data-bs-target="#menu">

<span class="navbar-toggler-icon"></span>

</button>

<div
class="collapse navbar-collapse"
id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">

<a class="nav-link"
href="#">

Home

</a>

</li>

<li class="nav-item">

<a class="nav-link"
href="#how">

How It Works

</a>

</li>

<li class="nav-item">

<a class="nav-link"
href="#features">

Features

</a>

</li>

<li class="nav-item">

<a class="nav-link"
href="#contact">

Contact

</a>

</li>

</ul>

</div>

</div>

</nav>

<section class="hero">

<div class="container text-center">

<h1>

AI Powered Website Intelligence

</h1>

<p>

Paste any company website URL and instantly discover what they do, who they serve, their automation potential, and whether they're a Hot, Warm, or Cold lead.

</p>

<div class="input-group mt-5">

<input
id="url"
class="form-control form-control-lg"
placeholder="https://company.com">

<button
class="btn btn-info"
id="analyze">

Analyze

</button>

</div>

<div
id="loader"
style="display:none"
class="mt-4">

<div class="spinner-border text-info"></div>

<p class="mt-3">

Analyzing Website...

</p>

</div>

<div
id="results"
class="row mt-5">

</div>

</div>

</section>

<script
src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>

<script
src="js/script.js"></script>

</body>

</html>

'@

Set-Content "$Project\index.html" $HTML

Write-Host ""
Write-Host "index.html created." -ForegroundColor Green