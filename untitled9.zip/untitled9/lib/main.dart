﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'models/flashcard.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => FlashcardProvider(),
      child: const MyApp(),
    ),
  );
}

class FlashcardProvider extends ChangeNotifier {
  List<Flashcard> _cards = [];

  List<Flashcard> get cards => _cards;

  FlashcardProvider() {
    _loadCards();
  }

  void addCard(String question, String answer) {
    final card = Flashcard(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      question: question,
      answer: answer,
      createdAt: DateTime.now(),
    );
    _cards.add(card);
    _saveCards();
    notifyListeners();
  }

  void updateCard(String id, String question, String answer) {
    final index = _cards.indexWhere((card) => card.id == id);
    if (index != -1) {
      _cards[index] = Flashcard(
        id: id,
        question: question,
        answer: answer,
        createdAt: _cards[index].createdAt,
      );
      _saveCards();
      notifyListeners();
    }
  }

  void deleteCard(String id) {
    _cards.removeWhere((card) => card.id == id);
    _saveCards();
    notifyListeners();
  }

  Future<void> _loadCards() async {
    final prefs = await SharedPreferences.getInstance();
    final String? data = prefs.getString('flashcards');
    if (data != null) {
      final List<dynamic> decoded = json.decode(data);
      _cards = decoded.map((item) => Flashcard.fromJson(item)).toList();
      notifyListeners();
    }
  }

  Future<void> _saveCards() async {
    final prefs = await SharedPreferences.getInstance();
    final String encoded = json.encode(_cards.map((card) => card.toJson()).toList());
    await prefs.setString('flashcards', encoded);
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flashcard Quiz App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
