﻿import '../models/quote.dart';

class QuotesData {
  static List<Quote> getQuotes() {
    return [
      Quote(
        text: "The only way to do great work is to love what you do.",
        author: "Steve Jobs",
      ),
      Quote(
        text: "In the middle of difficulty lies opportunity.",
        author: "Albert Einstein",
      ),
      Quote(
        text: "Life is what happens when you're busy making other plans.",
        author: "John Lennon",
      ),
      Quote(
        text: "The purpose of our lives is to be happy.",
        author: "Dalai Lama",
      ),
      Quote(
        text: "Get busy living or get busy dying.",
        author: "Stephen King",
      ),
      Quote(
        text: "You only live once, but if you do it right, once is enough.",
        author: "Mae West",
      ),
      Quote(
        text: "Be the change you wish to see in the world.",
        author: "Mahatma Gandhi",
      ),
      Quote(
        text: "In three words I can sum up everything I've learned about life: it goes on.",
        author: "Robert Frost",
      ),
      Quote(
        text: "To live is the rarest thing in the world. Most people exist, that is all.",
        author: "Oscar Wilde",
      ),
      Quote(
        text: "The only thing we have to fear is fear itself.",
        author: "Franklin D. Roosevelt",
      ),
      Quote(
        text: "Success is not final, failure is not fatal: it is the courage to continue that counts.",
        author: "Winston Churchill",
      ),
      Quote(
        text: "The best way to predict the future is to create it.",
        author: "Peter Drucker",
      ),
      Quote(
        text: "It does not matter how slowly you go as long as you do not stop.",
        author: "Confucius",
      ),
      Quote(
        text: "The only impossible journey is the one you never begin.",
        author: "Tony Robbins",
      ),
      Quote(
        text: "Act as if what you do makes a difference. It does.",
        author: "William James",
      ),
      Quote(
        text: "The journey of a thousand miles begins with one step.",
        author: "Lao Tzu",
      ),
      Quote(
        text: "Innovation distinguishes between a leader and a follower.",
        author: "Steve Jobs",
      ),
      Quote(
        text: "The greatest glory in living lies not in never falling, but in rising every time we fall.",
        author: "Nelson Mandela",
      ),
      Quote(
        text: "The future belongs to those who believe in the beauty of their dreams.",
        author: "Eleanor Roosevelt",
      ),
      Quote(
        text: "It is during our darkest moments that we must focus to see the light.",
        author: "Aristotle",
      ),
    ];
  }
}
