﻿
// ======================================
// Sticky Header
// ======================================

window.addEventListener("scroll",()=>{

const header=document.querySelector("header");

if(window.scrollY>80){

header.style.background="#062b69";
header.style.boxShadow="0 8px 20px rgba(0,0,0,.25)";

}else{

header.style.background="#0B3D91";
header.style.boxShadow="0 5px 15px rgba(0,0,0,.15)";

}

});

// ======================================
// Smooth Scroll
// ======================================

document.querySelectorAll('a[href^="#"]').forEach(anchor=>{

anchor.addEventListener("click",function(e){

e.preventDefault();

const target=document.querySelector(this.getAttribute("href"));

if(target){

target.scrollIntoView({

behavior:"smooth"

});

}

});

});

// ======================================
// Reveal Cards
// ======================================

const observer=new IntersectionObserver(entries=>{

entries.forEach(entry=>{

if(entry.isIntersecting){

entry.target.style.opacity="1";
entry.target.style.transform="translateY(0px)";

}

});

});

document.querySelectorAll(".card").forEach(card=>{

card.style.opacity="0";
card.style.transform="translateY(50px)";
card.style.transition=".6s";

observer.observe(card);

});

// ======================================
// Scroll To Top
// ======================================

const topBtn=document.createElement("button");

topBtn.innerHTML="↑";

topBtn.className="topBtn";

document.body.appendChild(topBtn);

topBtn.style.position="fixed";
topBtn.style.bottom="30px";
topBtn.style.right="30px";
topBtn.style.width="55px";
topBtn.style.height="55px";
topBtn.style.border="none";
topBtn.style.borderRadius="50%";
topBtn.style.background="#ff9800";
topBtn.style.color="#fff";
topBtn.style.fontSize="22px";
topBtn.style.cursor="pointer";
topBtn.style.display="none";
topBtn.style.zIndex="9999";

window.addEventListener("scroll",()=>{

if(window.scrollY>300){

topBtn.style.display="block";

}else{

topBtn.style.display="none";

}

});

topBtn.onclick=()=>{

window.scrollTo({

top:0,

behavior:"smooth"

});

};

// ======================================
// Counter Animation
// ======================================

function animateCounter(element,target){

let count=0;

let speed=target/100;

let timer=setInterval(()=>{

count+=speed;

if(count>=target){

count=target;

clearInterval(timer);

}

element.innerHTML=Math.floor(count)+"+";

},20);

}

document.querySelectorAll(".counter").forEach(counter=>{

animateCounter(counter,

parseInt(counter.dataset.target));

});

// ======================================
// Contact Form Validation
// ======================================

const form=document.querySelector("form");

if(form){

form.addEventListener("submit",function(e){

const name=document.querySelector('input[name="name"]');

const email=document.querySelector('input[name="email"]');

if(name.value.trim()===""){

alert("Please enter your name.");

e.preventDefault();

return;

}

if(email.value.trim()===""){

alert("Please enter your email.");

e.preventDefault();

return;

}

});

}

console.log("USA Business Center Loaded");


const slides=document.querySelectorAll(".slide");

let current=0;

function changeSlide(){

slides[current].classList.remove("active");

current++;

if(current>=slides.length){

current=0;

}

slides[current].classList.add("active");

}

setInterval(changeSlide,5000);


window.addEventListener("load",()=>{

const loader=document.getElementById("loader");

if(loader){

setTimeout(()=>{

loader.style.display="none";

},800);

}

});

