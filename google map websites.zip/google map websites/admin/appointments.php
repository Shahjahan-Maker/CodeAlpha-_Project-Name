
<?php

session_start();

include "../php/config.php";

if(!isset($_SESSION["admin"])){

header("Location:index.php");

exit();

}

$result=$conn->query("SELECT * FROM appointments ORDER BY id DESC");

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Appointment Management</title>

<link rel="stylesheet" href="../css/style.css">

</head>

<body>

<header>

<div class="logo">

Appointment Manager

</div>

<nav>

<a href="dashboard.php" class="btn">

Dashboard

</a>

<a href="customers.php" class="btn">

Customers

</a>

<a href="logout.php" class="btn">

Logout

</a>

</nav>

</header>

<section class="services">

<h2>

Appointments

</h2>

<table width="100%" border="1" cellpadding="12">

<tr>

<th>ID</th>

<th>Name</th>

<th>Email</th>

<th>Phone</th>

<th>Service</th>

<th>Date</th>

<th>Time</th>

</tr>

<?php

while($row=$result->fetch_assoc()){

?>

<tr>

<td><?=$row["id"]?></td>

<td><?=$row["name"]?></td>

<td><?=$row["email"]?></td>

<td><?=$row["phone"]?></td>

<td><?=$row["service"]?></td>

<td><?=$row["appointment_date"]?></td>

<td><?=$row["appointment_time"]?></td>

</tr>

<?php } ?>

</table>

</section>

</body>

</html>

