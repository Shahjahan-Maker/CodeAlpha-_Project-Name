﻿
<?php

session_start();

include "../php/config.php";

if(isset($_POST["username"])){

$username=$_POST["username"];

$password=md5($_POST["password"]);

$sql="SELECT * FROM admin

WHERE username='$username'

AND password='$password'";

$result=$conn->query($sql);

if($result->num_rows>0){

$_SESSION["admin"]=$username;

header("Location:dashboard.php");

exit();

}

$error="Invalid Login";

}

?>

<!DOCTYPE html>

<html>

<head>

<title>Admin Login</title>

<link rel="stylesheet" href="../css/style.css">

</head>

<body>

<div class="contact-form" style="max-width:500px;margin:100px auto;">

<h2>Admin Login</h2>

<?php if(isset($error)){ ?>

<p style="color:red"><?php echo $error; ?></p>

<?php } ?>

<form method="post">

<input type="text" name="username" placeholder="Username" required>

<input type="password" name="password" placeholder="Password" required>

<button type="submit">

Login

</button>

</form>

</div>

</body>

</html>

