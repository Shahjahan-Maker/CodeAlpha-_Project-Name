
<?php

session_start();

include "../php/config.php";

if(!isset($_SESSION["admin"])){

header("Location:index.php");

exit();

}

$message="";

if(isset($_POST["upload"])){

$target="../images/uploads/";

if(!file_exists($target)){

mkdir($target,0777,true);

}

$fileName=time()."_".basename($_FILES["image"]["name"]);

$targetFile=$target.$fileName;

$imageType=strtolower(pathinfo($targetFile,PATHINFO_EXTENSION));

$allowed=array("jpg","jpeg","png","gif","webp");

if(in_array($imageType,$allowed)){

if(move_uploaded_file($_FILES["image"]["tmp_name"],$targetFile)){

$message="Image Uploaded Successfully";

}else{

$message="Upload Failed";

}

}else{

$message="Invalid File Type";

}

}

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Image Upload</title>

<link rel="stylesheet" href="../css/style.css">

</head>

<body>

<header>

<div class="logo">

Image Manager

</div>

<a href="dashboard.php" class="btn">

Dashboard

</a>

</header>

<section class="services">

<h2>

Upload Gallery Images

</h2>

<p><?=$message?></p>

<form

method="post"

enctype="multipart/form-data">

<input

type="file"

name="image"

required>

<br><br>

<button

name="upload"

class="btn">

Upload Image

</button>

</form>

</section>

</body>

</html>

