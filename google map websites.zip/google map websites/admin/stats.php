
<?php

$totalCustomers=$conn->query("SELECT COUNT(*) total FROM contacts")->fetch_assoc()["total"];

$totalAppointments=$conn->query("SELECT COUNT(*) total FROM appointments")->fetch_assoc()["total"];

?>

<div class="stats">

<div class="stat">

<h2><?=$totalCustomers?></h2>

<p>Total Customers</p>

</div>

<div class="stat">

<h2><?=$totalAppointments?></h2>

<p>Total Appointments</p>

</div>

</div>

