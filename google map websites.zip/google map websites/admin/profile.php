
<?php

session_start();

if(!isset($_SESSION["admin"])){

header("Location:index.php");

exit();

}

?>

<!DOCTYPE html>

<html>

<head>

<title>Admin Profile</title>

<link rel="stylesheet" href="../css/style.css">

</head>

<body>

<header>

<div class="logo">

Administrator

</div>

</header>

<section class="services">

<div class="card">

<h2>

Welcome

<?=$_SESSION["admin"]?>

</h2>

<p>

Manage customers, appointments, blog posts and uploaded images from your dashboard.

</p>

<a href="dashboard.php" class="btn">

Dashboard

</a>

</div>

</section>

</body>

</html>

