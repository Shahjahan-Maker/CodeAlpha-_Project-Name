﻿
<?php

session_start();

if(!isset($_SESSION["admin"])){

header("Location:index.php");

exit();

}

include "../php/config.php";

?>

<!DOCTYPE html>

<html>

<head>

<title>Dashboard</title>

<link rel="stylesheet" href="../css/style.css">

</head>

<body>

<header>

<div class="logo">

Admin Dashboard

</div>

<a class="btn"

href="logout.php">

Logout

</a>

</header>

<section class="services">

<h2>

Customer Messages

</h2>

<table border="1"

cellpadding="15"

width="100%">

<tr>

<th>Name</th>

<th>Email</th>

<th>Phone</th>

<th>Service</th>

<th>Message</th>

</tr>

<?php

$result=$conn->query("SELECT * FROM contacts ORDER BY id DESC");

while($row=$result->fetch_assoc()){

?>

<tr>

<td><?=$row['name']?></td>

<td><?=$row['email']?></td>

<td><?=$row['phone']?></td>

<td><?=$row['service']?></td>

<td><?=$row['message']?></td>

</tr>

<?php } ?>

</table>

</section>

</body>

</html>

