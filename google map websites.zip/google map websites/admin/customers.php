
<?php

session_start();

include "../php/config.php";

if(!isset($_SESSION["admin"])){

header("Location:index.php");

exit();

}

$result=$conn->query("SELECT * FROM contacts ORDER BY id DESC");

?>

<!DOCTYPE html>

<html>

<head>

<title>Customers</title>

<link rel="stylesheet" href="../css/style.css">

</head>

<body>

<header>

<div class="logo">

Customer Management

</div>

<a href="dashboard.php" class="btn">

Dashboard

</a>

</header>

<section class="services">

<h2>

Customer Messages

</h2>

<table border="1" width="100%" cellpadding="12">

<tr>

<th>ID</th>

<th>Name</th>

<th>Email</th>

<th>Phone</th>

<th>Service</th>

</tr>

<?php while($row=$result->fetch_assoc()){ ?>

<tr>

<td><?=$row["id"]?></td>

<td><?=$row["name"]?></td>

<td><?=$row["email"]?></td>

<td><?=$row["phone"]?></td>

<td><?=$row["service"]?></td>

</tr>

<?php } ?>

</table>

</section>

</body>

</html>

