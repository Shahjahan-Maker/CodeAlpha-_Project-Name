﻿
<?php

include "config.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$name=$conn->real_escape_string($_POST["name"]);

$email=$conn->real_escape_string($_POST["email"]);

$phone=$conn->real_escape_string($_POST["phone"]);

$service=$conn->real_escape_string($_POST["service"]);

$message=$conn->real_escape_string($_POST["message"]);

$sql="INSERT INTO contacts

(name,email,phone,service,message)

VALUES

('$name','$email','$phone','$service','$message')";

if($conn->query($sql)){

echo "<script>

alert('Thank you! Your message has been sent.');

window.location='../contact.html';

</script>";

}else{

echo "Database Error";

}

}

?>

