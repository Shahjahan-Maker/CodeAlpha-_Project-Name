
<?php

function sendNotification($to,$name,$service){

$subject="Appointment Confirmation";

$message="Hello ".$name."

Your appointment for ".$service."

has been received.

Thank you.";

$headers="From: noreply@usabusinesscenter.com";

mail($to,$subject,$message,$headers);

}

?>

