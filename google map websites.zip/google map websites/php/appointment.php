﻿
<?php

include "config.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){

$name=$conn->real_escape_string($_POST["name"]);

$email=$conn->real_escape_string($_POST["email"]);

$phone=$conn->real_escape_string($_POST["phone"]);

$service=$conn->real_escape_string($_POST["service"]);

$date=$conn->real_escape_string($_POST["date"]);

$time=$conn->real_escape_string($_POST["time"]);

$sql="INSERT INTO appointments

(name,email,phone,service,appointment_date,appointment_time)

VALUES

('$name','$email','$phone','$service','$date','$time')";

if($conn->query($sql)){

echo "<script>

alert('Appointment Booked Successfully');

window.location='../contact.html';

</script>";

}else{

echo $conn->error;

}

}

?>

