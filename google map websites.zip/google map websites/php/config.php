﻿
<?php

$host="localhost";

$username="root";

$password="";

$database="business_center";

$conn=new mysqli(

$host,

$username,

$password,

$database

);

if($conn->connect_error){

die("Database Connection Failed");

}

?>

