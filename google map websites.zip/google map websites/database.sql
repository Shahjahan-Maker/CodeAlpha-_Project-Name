﻿
CREATE DATABASE business_center;

USE business_center;

CREATE TABLE admin(

id INT AUTO_INCREMENT PRIMARY KEY,

username VARCHAR(100),

password VARCHAR(255)

);

INSERT INTO admin(username,password)

VALUES

('admin',MD5('admin123'));

CREATE TABLE contacts(

id INT AUTO_INCREMENT PRIMARY KEY,

name VARCHAR(100),

email VARCHAR(150),

phone VARCHAR(30),

service VARCHAR(100),

message TEXT,

created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);

CREATE TABLE appointments(

id INT AUTO_INCREMENT PRIMARY KEY,

name VARCHAR(100),

email VARCHAR(150),

phone VARCHAR(30),

service VARCHAR(100),

appointment_date DATE,

appointment_time TIME,

created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);

